# formwork_methods_calc：方法公式＋計算程式

> 模板大師（design-build-review-concrete-formwork）ChatGPT 知識檔｜依據：台灣法規與國內規範（首要）＋ Peurifoy & Oberlender《Formwork for Concrete Structures》第 4 版（2011，計算方法）｜全公制｜2026-11-11

# 方法與模式（Patterns）

全檔公制。每一模式先列台灣基準（tw_basis.md 編號），再列計算方法。計算方法源自原書（Peurifoy & Oberlender, 2011；ACI 347-04、NDS-2005、APA），原書美制公式已由本 skill 精確換算為 SI 單位一致式，換算常數列於 P0；原書原頁見 source_tables.pdf。

---

## P0 單位與換算常數（本 skill 統一使用）

| 量 | 單位 | 本 skill 採用之換算（原書美制→SI） |
|---|---|---|
| 長度 | m、mm | 1 ft＝0.3048 m；1 in.＝25.4 mm |
| 壓力 | kPa | 1 psf＝0.04788 kPa |
| 應力、彈性模數 | MPa | 1 psi＝0.006895 MPa |
| 單位重 | kN/m³ | 1 pcf＝0.1571 kN/m³（150 pcf＝23.56 kN/m³） |
| 線載重 | kN/m（＝N/mm） | 1 plf＝0.01459 kN/m |
| 力 | kN | 1 lbf＝4.448 N |
| 溫度 | °C | T(°F)＝1.8T(°C)＋32 |
| 澆置速率 | m/h | 1 ft/hr＝0.3048 m/h |
| 合板性質 | 每公尺寬 mm³/m、mm⁴/m、mm²/m | 原書每英尺寬值 ×(1,000/304.8) |

國內舊式單位：1 kgf/cm²＝0.0981 MPa；1 tf/m²＝9.81 kPa。

---

## P1 側壓力

**台灣基準**：TW-S03（載重種類，數值依 ACI 347）；03110 國土署 2.2.2、水利署 2.2.5（ACI 347 或 JASS 5）。
**做法**：
1. 分類：任一平面尺寸 > 2.0 m 為牆，否則為柱（原書第 3 章）。
2. 前提：坍度 ≤ 175 mm、內部振動深度 ≤ 1.2 m；不符、自充填或強力振動 → Pm＝γh。
3. 自模板底部泵送 → Pm ≥ 1.25γh。
4. 選式（Pm：kPa；R：m/h；T：混凝土溫度 °C；γ：kN/m³；h：m）：

| 條件 | 公式（原書式號） |
|---|---|
| 柱（建議） | Pm＝γh（Eq. 3-1） |
| 柱（限定條件） | Pm＝CwCc[7.18＋785R/(T＋17.8)]（Eq. 3-4） |
| 牆，R < 2.1 m/h 且 h ≤ 4.27 m | Pm＝CwCc[7.18＋785R/(T＋17.8)]（Eq. 3-2） |
| 牆，2.1 ≤ R ≤ 4.6 m/h，或 h > 4.27 m | Pm＝CwCc[7.18＋1,154/(T＋17.8)＋244R/(T＋17.8)]（Eq. 3-3） |
| 牆，R > 4.6 m/h | Pm＝γh |

5. 夾限：28.7Cw ≤ Pm ≤ γh（kPa）。
6. 分布：頂部 0，深度 Pm/γ 處達 Pm，以下等值。
7. 澆置速率：R＝每小時澆置量（m³/h）÷ 每 1 m 高之模內體積（m³/m）。
8. Cw：γ < 22.0 kN/m³：0.5(1＋γ/22.78)，不小於 0.8；22.0～23.6：1.0；> 23.6：γ/22.78。Cc：見 cheatsheet §2。

**取捨**：常數由原書美制精確換算；ACI 347 公制版本可能取整（例如下限、門檻值），引用時註明採用版本。原書 Table 3-3～3-5 有 3 格與公式不符（E-01～E-03），以公式為準。

---

## P2 垂直載重

**台灣基準**：TW-S03、TW-S13（依實際可能發生者估計）；TW-L17 偏心載重；TW-L18 材料堆置。
**做法**（數值依 ACI 347，原書第 3 章；附錄 B）：
1. 混凝土＋鋼筋：γ × 板厚（常重 23.6 kN/m³：每 10 mm 板厚 0.236 kPa）。
2. 模板自重：先估 0.48 kPa，設計完成後核對。
3. 施工活載重：≥ 2.4 kPa；機動料車 ≥ 3.6 kPa。
4. 靜活載合計下限：4.8 kPa（機動料車 6.0 kPa）。
5. 衝擊：料斗落料 F＝M√(2gh)/T（M：料斗內混凝土重量換算 kg；h：落距 m；T：卸空時間 s）。
6. 堆料、泵管、機具另計並加強。

---

## P3 材料容許應力

**台灣基準**：TW-S04（彈性模數與容許應力依相關規範，多次使用應考慮衰減）；TW-L01 材料不得明顯損壞變形腐蝕；CNS 8057、CNS 5644。
**做法**：
1. 台灣材料（CNS 8057 合板、角材、可調鋼管支柱、鋼模）：由試驗報告、製造商型錄或契約取得 Fb、Fv（或 Fs）、Fc⊥、E 與斷面性質，計算書註明來源；缺漏不自行推估（TW-P02～P04）。
2. 轉用多次者依 TW-S04 考慮承載力衰減（折減方式依製造商或設計者判斷，計算書明列）。
3. 原書美國材料（NDS）調整方法供參考：F′b＝Fb·CF·CD·CM·CL·Cfu·Cr；F′v＝Fv·CD·CM；F′c⊥＝Fc⊥·CM·Cb；E′＝E·CM；施工載重 CD＝1.25，E、Fc⊥ 不乘 CD；濕材 CM：Fb 0.85、Fv 0.97、Fc⊥ 0.67、Fc// 0.8、E 0.9。

---

## P4 木梁、角材容許跨距（原書 Table 5-3 之 SI 式）

**台灣基準**：撓度限值依契約（TW-S05 為 1/240；03110 國土署為 1/360）。
**做法**（w：kN/m＝N/mm；應力 MPa；b、d、l：mm；S：mm³；I：mm⁴）：

| 檢核 | 單跨（兩支承） | 連續（三支承以上） |
|---|---|---|
| 內力 | M＝wl²/8；V＝wl/2；Δ＝5wl⁴/384EI | M＝wl²/10；V＝0.625wl；Δ＝wl⁴/145.25EI |
| 彎曲 | lb＝√(8FbS/w) | lb＝√(10FbS/w) |
| 剪力（修正法） | lv＝Fv·b·d/(0.75w)＋2d | lv＝Fv·b·d/(0.9375w)＋2d |
| 撓度 l/n | lΔ＝[384EI/(5nw)]^⅓ | lΔ＝[145.25EI/(nw)]^⅓ |
| 撓度絕對值 Δ（mm） | lΔ＝[384EIΔ/(5w)]^¼ | lΔ＝[145.25EIΔ/w]^¼ |

三項取最小再取整；原書例題同時檢核 l/360 與 1.6 mm。

---

## P5 面板（合板）容許跨距與容許壓力（原書 Table 5-4、Eq. 4-1～4-7 之 SI 式）

**台灣基準**：CNS 8057；撓度依契約；TW-S06 襯板突出等級。
**做法**（q：kPa；以 1 m 寬帶計，w＝q N/mm；Se、I、Ib/Q 為每公尺寬）：
1. 斷面性質依面紋方向（面紋垂直支承用「平行面紋」性質）；跨數：面紋垂直支承之支承間距 ≤ 0.81 m 視為三跨、> 0.81 m 兩跨；面紋平行支承 ≤ 0.41 m 三跨、0.51～0.61 m 兩跨、> 0.61 m 單跨。
2. 跨長：彎曲用中心距；彎曲撓度用淨距＋6 mm（50 mm 級支承）或＋16 mm（100 mm 級）；滾動剪力與剪力撓度用淨距。

| 檢核 | 單跨 | 兩跨 | 三跨以上 |
|---|---|---|---|
| 彎曲 | √(8FbSe/q) | √(8FbSe/q) | √(10FbSe/q) |
| 滾動剪力 | Fs(Ib/Q)/(0.5q) | Fs(Ib/Q)/(0.625q) | Fs(Ib/Q)/(0.6q) |
| 彎曲撓度 l/n | [76.8EI/(nq)]^⅓ | [185EI/(nq)]^⅓ | [145.25EI/(nq)]^⅓ |
| 剪力撓度 | Δs＝qCt²l²/(105.83EeI)，C＝120（面紋垂直支承）或 60 | 同左 | 同左 |

3. 已知支承間距求容許壓力：q_b＝k·FbSe/l²；q_s＝Fs(Ib/Q)/(kv·l)；q_d＝kd·EIΔ/ld⁴。
4. 跨厚比 l/t 介於 30～50 時剪力撓度小；≤ 15～20 時須另計並相加。

**取捨**：未取得有效斷面性質時，以實心矩形近似僅供初估（程式標示警告），正式計算須用試驗或製造商資料。

---

## P6 牆模設計程序

**台灣基準**：TW-L02～L06（簽章、澆置計畫、查驗）、TW-S08（開口、繫條端距 ≥ 20 mm）、TW-S06（許可差）。
1. 側壓 Pm（P1）。
2. 面板：q＝Pm → 容許跨距 → 取整為小肋間距 s1。
3. 小肋：w＝Pm × s1 → 容許跨距 → 大肋間距 s2。
4. 承壓：P＝Pm·s1·s2；fc⊥ ≤ F′c⊥。
5. 大肋：w＝Pm × s2 → 容許跨距 s3a；繫結器 s3b＝安全荷重 ÷ w；s3＝min 取整。
6. 繫結器拉力 T＝Pm·s2·s3 ≤ 安全荷重（極限強度 ÷ 2.0，原書 Table 5-10）。
7. 配置：最下排大肋接近底部；上部低壓區可放大；地方規範另有規定者從之（例：桃園市繫結器最下端離地 < 30 cm）。
8. 斜撐：P10。
**原書驗證例（SI）**：牆高 3.66 m、R＝1.83 m/h、26.7 °C → 39.5 kPa；面板 → 小肋 305 mm；38×89 mm 小肋 → 大肋 610 mm；繫結器拉力 14.7 kN → 採 17.8 kN 級。

---

## P7 柱模設計程序

**台灣基準**：TW-S08（每 2～3 m 臨時澆置開口）；地方規範（例：桃園市柱每 1.5 m 一澆置孔）。
1. Pm＝γh（全高），必要時逐深度計算。
2. 面板直接跨柱箍：容許跨距＝柱箍間距。
3. 合板加立肋：合板跨立肋淨距（P5）；立肋受載寬＝至相鄰立肋中點；立肋容許跨距＝柱箍間距（P4）。
4. 柱箍：製造商資料；木柱箍端箍 S＝wx²/(8Fb)、側箍 S＝wx(2y−x)/(8Fb)，w＝P·l（N/mm）；端部剪力長度 ≥ 75 mm；柱箍交錯 90°。
**原書驗證例（SI）**：508 mm 方柱高 3.05 m、71.8 kPa；中央立肋線載 17.1 kN/m → 394 mm（剪力）→ 底部柱箍 305 mm。

---

## P8 樓板模設計程序

**台灣基準**：TW-L09～L15（基礎、繫條、支柱型式）、TW-L17（偏心載重）、TW-S07（預拱）。
1. 載重 q（P2）。
2. 面板 → 小梁間距 s1。
3. 小梁：w＝q·s1 → 大梁間距 s2。
4. 承壓（小梁／大梁）。
5. 大梁：w＝q·s2 → 支柱間距 s3。
6. 支柱載重 P＝q·s2·s3 ≤ 支柱容許載重（P9）。
7. 承壓、墊板與基礎（TW-L09）或下層樓板（P12）。
8. 側向繫撐（P10）與法規繫條（TW-L11～L15）。
**原書驗證例（SI）**：板厚 178 mm → 6.85 kPa；小梁 508 mm、大梁 1,219 mm、支柱 1,524 mm；每支支柱 12.7 kN。

---

## P9 支柱容量

**台灣基準**：可調鋼管支柱依 CNS 5644／5645 與製造商（TW-L12，不得連接使用；> 3.5 m 每 2 m 內水平繫條）；鋼管施工架（TW-L13）；型鋼支柱（TW-L14）；木支柱（TW-L15：一處接頭、淨高 ≤ 4 m、斷面 > 31.5 cm²、每 2 m 水平繫條）。
**做法**：
1. 製式支撐：採製造商試驗容許載重，安全係數依原書附錄 B（SSFI）：框式、扣件式、系統式 ≥ 2.5；單柱 ≥ 3.0；依實際高度與繫條間距選用。
2. 木支柱（原書 Eq. 5-61、5-62）：le/d ≤ 50；Fce＝0.822E′min/(le/d)²；CP＝(1＋Fce/F*c)/1.6 − √{[(1＋Fce/F*c)/1.6]² − (Fce/F*c)/0.8}；Pc＝F*c·CP·A。
3. 承壓上限：支柱載重 ≤ Fc⊥ × 上下接觸面積。

---

## P10 側向力與斜撐

**台灣基準**：TW-L08（橋梁支撐側向與水平支撐）、TW-S03（風力）、《建築物耐風設計規範》（TW-P05）。
- 牆模：模頂最小水平力＝q·h/2（q：風壓 kPa；未依規範計算時 ACI 347 最小值相當於 0.72 kPa），牆高 ≥ 2.44 m 時不小於 1.46 kN/m（原書 Table 5-7 之 SI 等式）。
- 板模：H＝max(1.46 kN/m, 0.02 × DL(kPa) × 板寬(m))，DL 含模板 0.72 kPa（原書 Table 5-8 之 SI 等式）；不平衡澆置或機具啟停時作結構分析。
- 斜撐：z＝√(x²＋y²)；軸力＝H·z/x；底部垂直反力＝H·y/x；水平反力＝H；斜撐上端低於模頂時 H 依高度比放大。
- 上述等式由原書表值反推，已逐格驗證（85 格）；正式依據為原表與契約風壓。

---

## P11 動態力

- 料斗落料：F＝M√(2gh)/T；降低卸料速率比降低落距有效（原書 Eq. 7-1）。
- 機動料車：F＝Ma；多台同時停止須相加（Eq. 7-2）。
- 台灣基準：TW-L17 避免過大振動、注意偏心載重、吊桶擺動夾角 ≤ 40°。

---

## P12 多層再撐

**台灣基準**：TW-S12（再撐計畫報核、當日完成、能力不少於上層支撐之一半並對準、延伸至各樓層）；TW-L19（新樓板上澆置上層應充分考量受力）。
**分析因子（原書第 6 章）**：樓板設計載重、混凝土與模板靜載、施工活載、設計強度、澆置週期、受載時強度、各階段載重分配、樓板跨度、模板系統、最小齡期；檢核最大支柱載重下之穿孔剪力。

---

## P13 拆模時機

**台灣基準（依序）**：
1. 契約採用之 03110 版本拆模時間表（經工程司同意）。
2. 結構混凝土施工規範表 4.7.1 最少拆模時間（TW-S11）。
3. 強度認定：版或梁拆除支撐時工地養護試體強度 ≥ 設計強度 70%（除經許可外，TW-S10）。
4. 摻卜作嵐材料或緩凝摻料應延長；養護氣溫低時酌增。
5. 原書 Table 5-9 與附錄 C（OSHA）僅供比較。

---

## P14 薄殼拱架幾何（原書第 13 章）

- R＝L²/(8H)＋H/2（m）；邊緣角 a＝arcsin(L/2R)；y＝R−√(R²−x²)。
- 拆拱架：試驗確認 f′c 與 E（E 以現場養護梁撓曲試驗）；由最大撓度處向最小撓度處；邊梁與殼體同步；03110 國土署規定拱架由拱頂分向起拱線逐次拆除。

---

## P15 模板轉用與套數（原書第 2 章）

1. 樓層分區、訂定週期；2. 依各類模板最短留置時間（以 P13 台灣基準）；3. 排定各區模板來源，求所需套數。

---

## P16 滑模作業控制（原書第 15 章）

- 千斤頂間距 1.8～2.4 m；共用液壓泵；斷電自動保持裝置。
- 面板高約 1.2 m，兩側上窄下寬約 6 mm。
- 提升速率依凝結（約 50～300 mm/h 以上），由有經驗人員全程在場決定，不得超過預定安全速率。
- 台灣基準：03110 規定滑動模板屬特種模板，須送材料規格、廠商說明書、施工製造圖及設計計算書；適用 TW-L02 簽章門檻。


---

# 計算程式重建說明

將下列兩個程式碼區塊分別存為 `formwork_calc.py` 與 `formwork_tables.json`（同一資料夾），先執行 `python formwork_calc.py verify`（應為 103/103 通過）。

## formwork_calc.py

```python
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
formwork_calc.py — 模板大師計算程式（design-build-review-concrete-formwork）v1.1（公制）

單位（全程公制 SI）：長度 m 或 mm、力 kN 或 N、壓力 kPa、應力與彈性模數 MPa、單位重 kN/m³、
澆置速率 m/h、溫度 °C、線載重 kN/m（＝N/mm）。

依據層級（台灣優先）：
  1. 營造安全衛生設施標準第 130～146 條（程式不取代法規檢核，僅輸出提醒）
  2. 契約與施工規範（公共工程施工綱要規範第 03110 章、結構混凝土施工規範第四章）
     ─ 03110（國土管理署 2017/06）2.2.2：模板及支撐應能承受 ACI 347 所定載重與側壓
     ─ 撓度限值依契約：結構混凝土施工規範 4.3.4 為 1/240；國土署 03110 1.4.4 為 1/360
  3. 計算方法：Peurifoy & Oberlender《Formwork for Concrete Structures》4th ed., 2011（下稱原書，
     ACI 347-04、NDS-2005、APA）；原書美制公式已精確換算為 SI 單位一致式。

子指令：pressure、rate、slabload、stress、span、ply、shore、brace、impact、yoke、shell、strip、design、verify
材料容許值未提供時程式停止；台灣材料一律以 kind=user 輸入並註明來源。
"""
import argparse, json, math, os, sys

HERE = os.path.dirname(os.path.abspath(__file__))
TABLES = json.load(open(os.path.join(HERE, "formwork_tables.json"), encoding="utf-8"))

# ---------- 換算常數（僅供原書例題驗證與門檻換算） ----------
FT = 0.3048; IN = 25.4                     # m／ft；mm／in.
PSF = 0.04788026                           # kPa／psf
PCF = 0.15708746                           # kN/m³／pcf
PSI = 0.00689476                           # MPa／psi
PLF = 0.01459390                           # kN/m／plf
LBF = 4.44822                              # N／lbf
def _thk_mm(t):
    """原書合板標稱厚度（英寸分數字串）換算 mm，取整數。"""
    from fractions import Fraction
    try: return round(float(sum(Fraction(x) for x in str(t).split()) ) * 25.4)
    except Exception: return t

def f2c(f): return (f - 32.0) * 5.0 / 9.0
def c2f(c): return c * 1.8 + 32.0

# ---------- 側壓力（原書第 3 章；ACI 347-04；03110 2.2.2 引用 ACI 347） ----------
K0 = 150 * PSF                              # 7.182 kPa
K1 = 9000 / (FT * 1.8) * PSF                # 785.4
K2 = 43400 / 1.8 * PSF                      # 1154.4
K3 = 2800 / (FT * 1.8) * PSF                # 244.4
PMIN = 600 * PSF                            # 28.73 kPa（×Cw）
R_LIM1 = 7 * FT; R_LIM2 = 15 * FT           # 2.134、4.572 m/h
H_LIM = 14 * FT                             # 4.267 m
WALL_DIM = 6.5 * FT                         # 1.981 m
G_LO = 140 * PCF; G_HI = 150 * PCF; G_REF = 145 * PCF   # 21.99、23.56、22.78 kN/m³

def Cw_of(g):
    """Table 3-1（SI）：g 為混凝土單位重 kN/m³"""
    if g < G_LO: return max(0.8, 0.5 * (1 + g / G_REF))
    if g <= G_HI: return 1.0
    return g / G_REF

def lateral_pressure(member, h, R, T, g=23.56, Cc=1.0, Cw=None, pump_from_base=False, full=False):
    """h：澆置高度 m；R：澆置速率 m/h；T：混凝土溫度 °C；g：kN/m³。回傳 Pm（kPa）。"""
    if Cw is None: Cw = Cw_of(g)
    gh = g * h
    out = {"member": member, "h_m": h, "R_mh": R, "T_C": T, "g_kNm3": g, "Cw": round(Cw, 3), "Cc": Cc, "gh_kPa": round(gh, 2)}
    if pump_from_base:
        out.update(Pm=round(1.25 * gh, 2), eq="Pm＝1.25γh（自模板底部泵送，湧壓至少 25%，原書第 3 章）"); return out
    if full:
        out.update(Pm=round(gh, 2), eq="Pm＝γh（Eq.3-1；自充填、強力振動、坍度＞175 mm 或振動深度＞1.2 m）"); return out
    if member == "wall":
        if R > R_LIM2:
            out.update(Pm=round(gh, 2), eq="Pm＝γh（牆 R＞4.57 m/h，Eq.3-1）"); return out
        if R < R_LIM1 and h <= H_LIM:
            p = Cw * Cc * (K0 + K1 * R / (T + 17.78)); eq = "Pm＝CwCc[7.18＋785R/(T＋17.8)]（Eq.3-2 SI；R＜2.13 m/h 且 h≤4.27 m）"
        else:
            p = Cw * Cc * (K0 + K2 / (T + 17.78) + K3 * R / (T + 17.78)); eq = "Pm＝CwCc[7.18＋1,154/(T＋17.8)＋244R/(T＋17.8)]（Eq.3-3 SI）"
    elif member == "column":
        p = Cw * Cc * (K0 + K1 * R / (T + 17.78)); eq = "Pm＝CwCc[7.18＋785R/(T＋17.8)]（Eq.3-4 SI；原書建議柱取 γh）"
    else:
        raise ValueError("member 須為 wall 或 column")
    pmin = PMIN * Cw
    Pm = min(max(p, pmin), gh)
    gov = "公式值" if pmin <= p <= gh else ("下限 28.7Cw kPa" if p < pmin else "上限 γh")
    if pmin > gh: Pm = gh; gov = "上限 γh"
    out.update(Pm_calc=round(p, 2), Pmin=round(pmin, 2), Pm=round(Pm, 2), eq=eq, governs=gov, depth_of_Pm_m=round(Pm / g, 2))
    return out

def rate_from_pump(Q_m3h, L_m, t_m):
    """原書 Ex.3-3：R＝每小時澆置量 ÷ 每 1 m 高之模內體積"""
    return Q_m3h / (L_m * t_m)

# ---------- 樓板垂直載重（原書第 3 章；附錄 B 2.5～2.6） ----------
LL = 50 * PSF; LL_MOT = 75 * PSF; TOT_MIN = 100 * PSF; TOT_MOT = 125 * PSF; FORM_DL = 10 * PSF
def slab_load(t_mm, g=23.56, form_dl=None, motorized=False, ll=None):
    conc = g * t_mm / 1000.0
    form_dl = FORM_DL if form_dl is None else form_dl
    if ll is None: ll = LL_MOT if motorized else LL
    tot = conc + form_dl + ll
    tmin = TOT_MOT if motorized else TOT_MIN
    return {"concrete_kPa": round(conc, 3), "form_dl_kPa": round(form_dl, 3), "ll_kPa": round(ll, 3),
            "total_kPa": round(max(tot, tmin), 3), "total_calc_kPa": round(tot, 3), "min_total_kPa": round(tmin, 3)}

# ---------- 木材容許應力（原書第 4 章，原書美國材料；MPa） ----------
def ref_values(species, grade, size):
    t, w = [int(x) for x in size.split("x")]
    rd = TABLES["ref_design_values"]
    if species == "SP":
        key = "2-4" if w <= 4 else str(min([6, 8, 10, 12], key=lambda k: abs(k - w)))
        v = rd["SP"][grade][key]
    else:
        v = rd[species][grade]
    return dict(zip(rd["_order"], v))

def CF_of(species, size):
    if species == "SP": return 1.0, 1.0
    t, w = [int(x) for x in size.split("x")]
    tab = TABLES["CF_table_4_3a"]; key = str(w) if str(w) in tab else ("14+" if w >= 14 else "12")
    row = tab[key]; return (row[1] if t >= 4 else row[0]), row[2]

def Cfu_of(size):
    t, w = [int(x) for x in size.split("x")]
    tab = TABLES["Cfu_table_4_7"]; key = "10+" if w >= 10 else str(w)
    v = tab[key][1 if t >= 4 else 0]; return 1.0 if v is None else v

def allowable(species, grade, size, CD=1.25, wet=False, flat=False, CF=None, Cr=1.0):
    r = ref_values(species, grade, size)
    cfb, cfc = CF_of(species, size)
    if CF is not None: cfb = CF
    cm = TABLES["CM_table_4_5"]
    CMb = cm["Fb"] if (wet and r["Fb"] * cfb >= 1150 * PSI) else 1.0
    CMv = cm["Fv"] if wet else 1.0
    CMcp = cm["Fc_perp"] if wet else 1.0
    CMc = cm["Fc_par"] if (wet and r["Fc_par"] * cfc >= 750 * PSI) else 1.0
    CME = cm["E"] if wet else 1.0
    cfu = Cfu_of(size) if flat else 1.0
    return {"Fb": round(r["Fb"] * cfb * CD * CMb * cfu * Cr, 3), "Fv": round(r["Fv"] * CD * CMv, 3),
            "Fc_perp": round(r["Fc_perp"] * CMcp, 3), "Fc_star": round(r["Fc_par"] * CD * CMc * cfc, 3),
            "E": round(r["E"] * CME, 1), "Emin": round(r["Emin"] * CME, 1),
            "factors": {"CF_b": cfb, "CF_c": cfc, "CD": CD, "CM_b": CMb, "CM_v": CMv, "CM_cperp": CMcp, "Cfu": cfu, "Cr": Cr},
            "unit": "MPa", "source": "原書 Table 4-2～4-8（美國材料，僅供比較；台灣材料請用 kind=user）"}

def section(size, flat=False):
    L = TABLES["lumber_S4S_dry"]["data"][size]
    if flat: return {"b": L["d"], "d": L["b"], "S": L["Sy"], "I": L["Iy"], "A": L["A"]}
    return {"b": L["b"], "d": L["d"], "S": L["Sx"], "I": L["Ix"], "A": L["A"]}

def rect(b, d, n=1):
    """矩形斷面（mm），n 支並列"""
    return {"b": b * n, "d": d, "A": b * d * n, "S": b * d * d / 6 * n, "I": b * d ** 3 / 12 * n}

# ---------- 構件容許跨距（原書 Table 5-3 之 SI 單位一致式） ----------
def parse_defl(c):
    """'l/360'→('ratio',360)；'1.6mm'→('abs',1.6)；'1/16in'→('abs',1.5875)"""
    c = c.strip()
    if c.startswith("l/"): return ("ratio", float(c[2:]))
    if c.endswith("mm"): return ("abs", float(c[:-2]))
    if c.endswith("in"):
        a, b = c[:-2].split("/"); return ("abs", float(a) / float(b) * IN)
    raise ValueError(f"撓度限值格式錯誤：{c}（例：l/360、l/240、1.6mm）")

DEFAULT_DEFL = ("l/360", "1.6mm")

def beam_spans(w, Fb, Fv, E, b, d, S=None, I=None, cond="multi", defl=DEFAULT_DEFL, modified_shear=True):
    """w：kN/m（＝N/mm）；應力 MPa；尺寸 mm。回傳容許跨距 mm。
    單跨：M＝wl²/8、V＝wl/2、Δ＝5wl⁴/384EI；連續（三支承以上，原書取值）：M＝wl²/10、V＝0.625wl、Δ＝wl⁴/145.25EI。"""
    S = S if S is not None else b * d * d / 6.0
    I = I if I is not None else b * d ** 3 / 12.0
    res = {}
    if cond == "single":
        res["bending"] = math.sqrt(8 * Fb * S / w)
        res["shear"] = Fv * b * d / (0.75 * w) + (2 * d if modified_shear else 0)
        k = 384 / 5.0
    else:
        res["bending"] = math.sqrt(10 * Fb * S / w)
        res["shear"] = Fv * b * d / (1.5 * 0.625 * w) + (2 * d if modified_shear else 0)
        k = 1743 / 12.0
    for c in defl:
        kind, v = parse_defl(c)
        if kind == "ratio": res[f"defl_{c}"] = (k * E * I / (v * w)) ** (1 / 3)
        else: res[f"defl_{c}"] = (k * E * I * v / w) ** 0.25
    res = {kk: round(vv, 0) for kk, vv in res.items()}
    g = min(res, key=res.get)
    return {"spans_mm": res, "governs": g, "max_span_mm": res[g], "cond": cond}

# ---------- 面板（原書 Table 5-4 SI；每公尺寬性質） ----------
def ply_spans(q, Fb, Fs, E, Se, I, IbQ, cond="multi", defl=DEFAULT_DEFL):
    """q：面板壓力 kPa（每公尺寬即 N/mm）；Se mm³/m、I mm⁴/m、IbQ mm²/m；回傳 mm。"""
    w = q  # N/mm（1 m 寬）
    kb = 8 if cond in ("single", "two") else 10
    kv = {"single": 0.5, "two": 0.625}.get(cond, 0.6)
    kd = {"single": 76.8, "two": 185.0}.get(cond, 145.25)
    res = {"bending": math.sqrt(kb * Fb * Se / w), "rolling_shear": Fs * IbQ / (kv * w)}
    for c in defl:
        kind, v = parse_defl(c)
        if kind == "ratio": res[f"defl_{c}"] = (kd * E * I / (v * w)) ** (1 / 3)
        else: res[f"defl_{c}"] = (kd * E * I * v / w) ** 0.25
    res = {kk: round(vv, 0) for kk, vv in res.items()}
    g = min(res, key=res.get)
    return {"spans_mm": res, "governs": g, "max_span_mm": res[g], "cond": cond,
            "note": "原書：彎曲以中心距、滾動剪力以淨距、彎曲撓度以淨距＋6 mm（50 mm 級支承）或＋16 mm（100 mm 級）計；原書例題將三者直接比較取最小。"}

def ply_pressure(span_cc, Fb, Fs, E, Se, I, IbQ, cond="multi", support_actual=38.1, support_class=50, defl="l/360", Ee=None, t=None, C=120):
    """已知支承中心距 mm，求各控制容許壓力 kPa（原書 Eq.4-1～4-7、5-38～5-59 之 SI 形式）。"""
    lb = span_cc; lc = span_cc - support_actual; ld = lc + (6.35 if support_class == 50 else 15.875)
    kb = 8 if cond in ("single", "two") else 10
    kv = {"single": 0.5, "two": 0.625}.get(cond, 0.6)
    kd = {"single": 76.8, "two": 185.0}.get(cond, 145.25)
    kind, v = parse_defl(defl); dlt = ld / v if kind == "ratio" else v
    res = {"bending": kb * Fb * Se / lb ** 2, "rolling_shear": Fs * IbQ / (kv * lc), f"bend_defl_{defl}": kd * E * I * dlt / ld ** 4}
    if Ee and t: res[f"shear_defl_{defl}"] = 105.83 * Ee * I * dlt / (C * t * t * lc ** 2)
    res = {kk: round(vv, 2) for kk, vv in res.items()}
    g = min(res, key=res.get)
    return {"pressure_kPa": res, "governs": g, "allow_kPa": res[g], "l_cc": lb, "l_clear": round(lc, 1), "l_defl": round(ld, 1)}

def plywood_deflection(q, l_clear, E, I, cond="multi", support_class=50, Ee=None, t=None, C=120):
    ld = l_clear + (6.35 if support_class == 50 else 15.875)
    kd = {"single": 76.8, "two": 185.0}.get(cond, 145.25)
    db = q * ld ** 4 / (kd * E * I)
    ds = q * C * t * t * l_clear ** 2 / (105.83 * Ee * I) if (Ee and t) else None
    return {"bending_defl_mm": round(db, 3), "shear_defl_mm": None if ds is None else round(ds, 3), "total_mm": round(db + (ds or 0), 3)}

# ---------- 支柱、承壓 ----------
def wood_shore(Fc_star, Emin, d_min, le, A, c=0.8):
    """原書 Eq.5-61、5-62；Fc*、Emin：MPa；d_min、le：mm；A：mm²；回傳 kN。le/d≤50。"""
    sr = le / d_min
    if sr > 50: return {"le_d": round(sr, 2), "ok": False, "msg": "le/d＞50，不得使用（原書第 5 章）"}
    Fce = 0.822 * Emin / sr ** 2
    r = Fce / Fc_star; a = (1 + r) / (2 * c)
    Cp = a - math.sqrt(a * a - r / c)
    Fc = Fc_star * Cp
    return {"le_d": round(sr, 2), "Fce_MPa": round(Fce, 3), "Cp": round(Cp, 4), "Fc_MPa": round(Fc, 3), "Pc_kN": round(Fc * A / 1000, 2), "ok": True}

def bearing(P_kN, A_mm2, Fc_perp, bearing_len=None):
    cb = (bearing_len + 9.525) / bearing_len if (bearing_len and bearing_len < 152.4) else 1.0
    f = P_kN * 1000 / A_mm2
    return {"fc_perp_MPa": round(f, 3), "allow_MPa": round(Fc_perp * cb, 3), "Cb": round(cb, 3), "ok": f <= Fc_perp * cb}

# ---------- 側向力與斜撐（原書 Table 5-7、5-8 之 SI 等式；由原表反推並逐格驗證） ----------
H_MIN = 100 * PLF      # 1.459 kN/m
Q_ACI = 15 * PSF       # 0.718 kPa
def wall_bracing_min(h, q=None):
    """h：模高 m；q：風壓 kPa（未給時用 ACI 347 之 0.718 kPa）。回傳模頂水平力 kN/m。"""
    q = Q_ACI if q is None else q
    v = q * h / 2.0
    if h >= 8 * FT - 1e-9: v = max(v, H_MIN)
    return round(v, 3)

def slab_bracing_min(dl_kPa, width_m):
    """max(1.46 kN/m, 2%×DL×板寬)；DL 含模板 0.72 kPa。"""
    return round(max(H_MIN, 0.02 * dl_kPa * width_m), 3)

def brace_force(H_top, spacing, h_form, x, y_attach):
    """H_top：kN/m；spacing、h_form、x、y_attach：m；回傳 kN"""
    H = H_top * spacing * h_form / y_attach
    z = math.hypot(x, y_attach)
    return {"H_kN": round(H, 2), "z_m": round(z, 3), "axial_kN": round(H * z / x, 2), "V_kN": round(H * y_attach / x, 2), "Hreact_kN": round(H, 2)}

# ---------- 動態力（原書第 7 章） ----------
GRAV = 9.80665
def bucket_impact(M_kg, h_m, T_s):
    """Eq.7-1 SI：F＝M√(2gh)/T（N→kN）"""
    return round(M_kg * math.sqrt(2 * GRAV * h_m) / T_s / 1000, 3)

def buggy_force(M_kg, v_kmh, t_s):
    """Eq.7-2 SI：F＝Ma"""
    return round(M_kg * (v_kmh / 3.6) / t_s / 1000, 3)

# ---------- 柱箍（原書 Eq.10-11、10-12 SI） ----------
def yoke_S(P_kPa, l_mm, x_mm, Fb, y_mm=None):
    w = P_kPa / 1000.0 * l_mm   # N/mm
    if y_mm is None: return round(w * x_mm ** 2 / (8 * Fb), 0)
    return round(w * x_mm * (2 * y_mm - x_mm) / (8 * Fb), 0)

# ---------- 薄殼（原書 Eq.13-2、13-3） ----------
def shell(L, H, n=10):
    R = L * L / (8 * H) + H / 2.0; half = L / 2.0
    pts = [(round(i * half / n, 3), round(R - math.sqrt(R * R - (i * half / n) ** 2), 4)) for i in range(n + 1)]
    return {"R_m": round(R, 3), "edge_slope_deg": round(math.degrees(math.asin(half / R)), 2), "points_x_ydown_m": pts}

# ---------- 拆模時間（台灣優先） ----------
STRIP_TW = {  # 結構混凝土施工規範表 4.7.1（第 I 型水泥、不摻卜作嵐材料）：(活載≤靜載, 活載＞靜載)
    "側模（柱牆梁不做支撐）": ("12 小時", "12 小時"),
    "雙向柵版盤模 ≤75 cm": ("3 天", "3 天"), "雙向柵版盤模 >75 cm": ("4 天", "4 天"),
    "單向版 <3 m": ("4 天", "3 天"), "單向版 3～6 m": ("7 天", "4 天"), "單向版 >6 m": ("10 天", "7 天"),
    "拱模": ("14 天", "7 天"),
    "梁底模 <3 m": ("7 天", "4 天"), "梁底模 3～6 m": ("14 天", "7 天"), "梁底模 >6 m": ("21 天", "14 天"),
    "雙向版": ("依 4.8 節再撐規定", "依 4.8 節再撐規定"), "後拉預力版": ("全部預力施加完成後", "全部預力施加完成後"),
}

# ---------- 串接設計（SI 輸入） ----------
def _ply_props(p):
    """sheathing：kind=user（台灣材料，必填來源）／plyform／plywood（原書美國材料參考）"""
    if p["kind"] == "user":
        miss = [k for k in ("Fb", "Fs", "E", "Se", "I", "IbQ") if p["props"].get(k) is None]
        if miss: sys.exit(f"面板材料缺少 {miss}（須由 CNS 8057 試驗報告或製造商提供，不自行推估）")
        d = dict(p["props"]); d.setdefault("src", p.get("source", "使用者提供（須附試驗報告或型錄）"))
        if not p.get("source"): d["src"] += "【未註明來源】"
        return d
    if p["kind"] == "plyform":
        pr = TABLES["plyform_table_4_11"][p["class"]][p["thk"]]; st = TABLES["plyform_table_4_12"][p["class"]]
        i = (1, 2, 3) if p.get("grain", "across") == "across" else (4, 5, 6)
        return {"I": pr[i[0]], "Se": pr[i[1]], "IbQ": pr[i[2]], "Fb": st["Fb"], "Fs": st["Fs"], "E": st["E"],
                "src": f"原書 Table 4-11/4-12 Plyform {p['class']} 厚 {_thk_mm(p['thk'])} mm（表列 {p['thk']}″，美國材料參考值）"}
    if p["kind"] == "plywood":
        pr = TABLES["plywood_table_4_9"][p.get("layup", "DiffSpecies")][p["thk"]]
        i = (3, 4, 5) if p.get("grain", "across") == "across" else (7, 8, 9)
        col = {"S1_wet": 0, "S1_dry": 1, "S2_wet": 2, "S2_dry": 3, "S3_dry": 4}[p["level"]]
        g = p["group"]; T10 = TABLES["plywood_table_4_10"]; gb = "1" if g == 1 else ("4" if g == 4 else "2-3")
        fs = "StructI_Marine" if p.get("layup") == "StructI_Marine" else "Others"; CD = p.get("CD", 1.25)
        return {"I": pr[i[0]], "Se": pr[i[1]], "IbQ": pr[i[2]], "Fb": T10["Fb"][gb][col] * CD, "Fs": T10["Fs"][fs][col] * CD,
                "E": T10["E"][str(min(g, 3))][col], "src": f"原書 Table 4-9/4-10 合板 Group {g} {p['level']} 厚 {_thk_mm(p['thk'])} mm（表列 {p['thk']}″，美國材料參考值），Fb、Fs×{CD}"}
    raise ValueError("sheathing.kind 須為 user／plyform／plywood")

def _lum(m, flat=False):
    if m.get("kind") == "user":
        miss = [k for k in ("Fb", "Fv", "E") if m["props"].get(k) is None]
        if miss: sys.exit(f"角材／鋼構件材料缺少 {miss}（須由試驗報告、規範或製造商提供，不自行推估）")
        n = m.get("ply", 1); s = rect(m["b_mm"], m["d_mm"], n) if "b_mm" in m else dict(m["section"])
        a = dict(m["props"]); a["src"] = m.get("source", "使用者提供（須附來源）【未註明來源】") if m.get("source") else "使用者提供【未註明來源】"
        a["src"] = m.get("source") or a["src"]; a.setdefault("Fc_perp", None)
        a["label"] = f"{('雙' if n == 2 else '')}{m['b_mm']:g}×{m['d_mm']:g} mm" if "b_mm" in m else "使用者斷面"
        return s, a
    a = allowable(m["species"], m["grade"], m["size"], CD=m.get("CD", 1.25), wet=m.get("wet", False), flat=flat)
    s = section(m["size"], flat=flat); n = m.get("ply", 1)
    s = {k: (v * n if k in ("b", "S", "I", "A") else v) for k, v in s.items()}
    a["src"] = f"原書 {m['species']} {m['grade']}（美國材料參考值）"; a["label"] = f"{('雙' if n == 2 else '')}{s['b']/n:.0f}×{s['d']:.0f} mm（標稱 {m['size']}）"
    return s, a

def _lines(r):
    names = {"bending": "彎曲", "shear": "剪力（修正法）", "rolling_shear": "滾動剪力"}
    return [f"- {names.get(k, '撓度 ' + k[5:] if k.startswith('defl_') else k)}：{v:,.0f} mm" for k, v in r.items()]

GOV = {"bending": "彎曲", "shear": "剪力（修正法）", "rolling_shear": "滾動剪力"}
def gov(k): return GOV.get(k, "撓度 " + k[5:] if k.startswith("defl_") else k)

def _nones(o, path=""):
    if o is None: return [path]
    if isinstance(o, dict): return sum((_nones(v, f"{path}.{k}" if path else k) for k, v in o.items()), [])
    if isinstance(o, list): return sum((_nones(v, f"{path}[{i}]") for i, v in enumerate(o)), [])
    return []

def design(inp):
    miss = _nones(inp)
    if miss: sys.exit("下列欄位待填（不自行推估）：\n  " + "\n  ".join(miss))
    typ = inp["type"]; defl = tuple(inp.get("deflection", ["l/360", "1.6mm"]))
    basis = inp.get("basis", {})
    md = [f"# {inp.get('title', '模板計算書')}", "",
          "## 0. 設計依據",
          f"- 法規：營造安全衛生設施標準第 130～146 條（支撐高度 {basis.get('shore_height_m', '〔待填〕')} m、投影面積 {basis.get('area_m2', '〔待填〕')} m²；"
          + ("達第 131 條第 1 款門檻（7 m 以上且 330 m² 以上），須由專任工程人員或執業技師設計簽章）" if (basis.get('shore_height_m', 0) >= 7 and basis.get('area_m2', 0) >= 330) else "未達或未填第 131 條第 1 款門檻者，依第 2 款得指派專人設計並簽章）"),
          f"- 施工規範：{basis.get('spec', '〔契約採用之 03110 版本與結構混凝土施工規範第四章，待填〕')}",
          f"- 撓度限值：{'、'.join(defl)}（依契約；結構混凝土施工規範 4.3.4 為 l/240，國土署 03110 1.4.4 為 l/360）",
          "- 側壓力與載重：03110（國土署 2017）2.2.2 引用 ACI 347；本計算採原書（ACI 347-04）公式之 SI 換算式。",
          "- 構件設計方法：原書第 5、9～11 章（彎曲、剪力、撓度三項檢核取最小）。", ""]
    R = {"type": typ, "basis": basis, "deflection": defl}
    if typ in ("wall", "column"):
        pr = inp["pressure"]
        P = {"Pm": pr["Pm_kPa"], "eq": "使用者指定"} if "Pm_kPa" in pr else lateral_pressure(
            typ, pr["h_m"], pr.get("R_mh", 99), pr.get("T_C", 20), pr.get("g_kNm3", 23.56), pr.get("Cc", 1.0),
            pump_from_base=pr.get("pump_from_base", False), full=pr.get("full_hydrostatic", False))
        Pm = P["Pm"]; R["pressure"] = P
        md += ["## 1. 設計側壓力", f"- {P['eq']}", f"- Pm＝{Pm:.1f} kPa" + (f"（控制：{P['governs']}）" if P.get("governs") else ""), ""]
        sh = _ply_props(inp["sheathing"])
        sp = ply_spans(Pm, sh["Fb"], sh["Fs"], sh["E"], sh["Se"], sh["I"], sh["IbQ"], defl=defl)
        R["sheathing"] = sp; s1 = inp.get("stud_spacing_mm") or int(sp["max_span_mm"] // 10 * 10)
        md += ["## 2. 面板", f"- 材料：{sh['src']}；Fb＝{sh['Fb']:.2f}、Fs＝{sh['Fs']:.3f}、E＝{sh['E']:,.0f} MPa", f"- 壓力 {Pm:.1f} kPa（1 m 寬帶，N/mm）",
               *_lines(sp["spans_mm"]), f"- 控制：{gov(sp['governs'])}，容許 {sp['max_span_mm']:,.0f} mm → 採用小肋間距 {s1} mm", ""]
        ss, sa = _lum(inp["studs"], flat=inp["studs"].get("flat", False)); w2 = Pm * s1 / 1000
        st = beam_spans(w2, sa["Fb"], sa["Fv"], sa["E"], ss["b"], ss["d"], ss["S"], ss["I"], defl=defl)
        R["studs"] = st; s2 = inp.get("wale_spacing_mm") or int(st["max_span_mm"] // 10 * 10)
        md += ["## 3. 小肋", f"- 材料：{sa['label']}，{sa['src']}；Fb＝{sa['Fb']:.2f}、Fv＝{sa['Fv']:.3f}、E＝{sa['E']:,.0f} MPa",
               f"- w＝{Pm:.1f}×{s1/1000:.3f}＝{w2:.2f} kN/m", *_lines(st["spans_mm"]),
               f"- 控制：{gov(st['governs'])}，容許 {st['max_span_mm']:,.0f} mm → 採用大肋（或柱箍）間距 {s2} mm", ""]
        if typ == "wall":
            ws, wa = _lum(inp["wales"]); w3 = Pm * s2 / 1000
            nply = inp["wales"].get("ply", 1); cw = inp["wales"].get("contact_width_mm", ss["b"])
            Abr = nply * ss["b"] * cw
            P1 = Pm * s1 / 1000 * s2 / 1000
            fcp = min(x for x in (sa.get("Fc_perp"), wa.get("Fc_perp")) if x) if (sa.get("Fc_perp") or wa.get("Fc_perp")) else None
            brg = bearing(P1, Abr, fcp) if fcp else {"msg": "未提供 Fc⊥，承壓待檢核"}
            wl = beam_spans(w3, wa["Fb"], wa["Fv"], wa["E"], ws["b"], ws["d"], ws["S"], ws["I"], defl=defl)
            R.update(bearing_stud_wale=brg, wales=wl)
            cap = inp.get("tie_safe_load_kN")
            s3 = inp.get("tie_spacing_mm") or int(wl["max_span_mm"] // 10 * 10)
            if cap: s3 = min(s3, int(cap / w3 * 1000 // 10 * 10))
            T = Pm * s2 / 1000 * s3 / 1000
            R["tie"] = {"spacing_mm": s3, "load_kN": round(T, 2), "safe_load_kN": cap, "ok": (cap is None or T <= cap)}
            md += ["## 4. 小肋與大肋承壓", (f"- P＝{P1:.2f} kN；A＝{Abr:,.0f} mm²；fc⊥＝{brg['fc_perp_MPa']:.2f} MPa ≤ {brg['allow_MPa']:.2f} MPa → {'OK' if brg['ok'] else 'NG'}" if "ok" in brg else f"- {brg['msg']}"), "",
                   "## 5. 大肋", f"- 材料：{wa['label']}，{wa['src']}", f"- w＝{w3:.2f} kN/m", *_lines(wl["spans_mm"]), f"- 控制：{gov(wl['governs'])}，容許 {wl['max_span_mm']:,.0f} mm", "",
                   "## 6. 繫結器", f"- 間距 {s3} mm；拉力＝{Pm:.1f}×{s2/1000:.3f}×{s3/1000:.3f}＝{T:.2f} kN",
                   f"- 安全荷重：{cap if cap else '〔待提供：製造商極限強度÷2.0（原書 Table 5-10）〕'} kN → {'OK' if R['tie']['ok'] else 'NG'}", ""]
            if inp.get("bracing"):
                b = inp["bracing"]; H = wall_bracing_min(b["h_m"], b.get("wind_kPa"))
                bf = brace_force(H, b["spacing_m"], b["h_m"], b["x_m"], b["y_attach_m"]); R["bracing"] = {"Hmin_kNm": H, **bf}
                md += ["## 7. 斜撐", f"- 模頂最小水平力 {H:.2f} kN/m（原書 Table 5-7 SI 等式；風壓依建築物耐風設計規範或契約）",
                       f"- 斜撐軸力 {bf['axial_kN']:.2f} kN；底部垂直反力 {bf['V_kN']:.2f} kN；水平反力 {bf['Hreact_kN']:.2f} kN", ""]
        else:
            md += ["## 4. 柱箍", "- 柱箍間距不得大於上列容許值；柱箍強度依製造商資料或原書 Eq.10-11／10-12 檢核。", ""]
    elif typ == "slab":
        s = inp["slab"]; L = slab_load(s["t_mm"], s.get("g_kNm3", 23.56), s.get("form_dl_kPa"), s.get("motorized", False), s.get("ll_kPa"))
        q = L["total_kPa"]; R["load"] = L
        md += ["## 1. 垂直設計載重", f"- 混凝土 {L['concrete_kPa']:.2f}＋模板 {L['form_dl_kPa']:.2f}＋施工活載重 {L['ll_kPa']:.2f}＝{L['total_calc_kPa']:.2f} kPa（下限 {L['min_total_kPa']:.2f}）→ 採用 {q:.2f} kPa", ""]
        sh = _ply_props(inp["sheathing"]); sp = ply_spans(q, sh["Fb"], sh["Fs"], sh["E"], sh["Se"], sh["I"], sh["IbQ"], defl=defl)
        R["decking"] = sp; s1 = inp.get("joist_spacing_mm") or int(sp["max_span_mm"] // 10 * 10)
        md += ["## 2. 面板", f"- 材料：{sh['src']}", *_lines(sp["spans_mm"]), f"- 控制：{gov(sp['governs'])} → 小梁間距 {s1} mm", ""]
        js, ja = _lum(inp["joists"]); wj = q * s1 / 1000
        jr = beam_spans(wj, ja["Fb"], ja["Fv"], ja["E"], js["b"], js["d"], js["S"], js["I"], defl=defl)
        R["joists"] = jr; s2 = inp.get("stringer_spacing_mm") or int(jr["max_span_mm"] // 10 * 10)
        md += ["## 3. 小梁", f"- 材料：{ja['label']}，{ja['src']}；Fb＝{ja['Fb']:.2f}、Fv＝{ja['Fv']:.3f}、E＝{ja['E']:,.0f} MPa", f"- w＝{wj:.2f} kN/m",
               *_lines(jr["spans_mm"]), f"- 控制：{gov(jr['governs'])} → 大梁間距 {s2} mm", ""]
        gs, ga = _lum(inp["stringers"]); wg = q * s2 / 1000
        sr = beam_spans(wg, ga["Fb"], ga["Fv"], ga["E"], gs["b"], gs["d"], gs["S"], gs["I"], defl=defl)
        s3 = inp.get("shore_spacing_mm") or int(sr["max_span_mm"] // 10 * 10)
        P = q * s2 / 1000 * s3 / 1000; R.update(stringers=sr, shore_load_kN=round(P, 2))
        fcp = ga.get("Fc_perp")
        if fcp:
            b1 = bearing(q * s1 / 1000 * s2 / 1000, js["b"] * gs["b"], fcp); R["bearing_joist_stringer"] = b1
        md += ["## 4. 小梁與大梁承壓", (f"- fc⊥＝{b1['fc_perp_MPa']:.2f} MPa ≤ {b1['allow_MPa']:.2f} MPa → {'OK' if b1['ok'] else 'NG'}" if fcp else "- 未提供 Fc⊥，承壓待檢核"), "",
               "## 5. 大梁", f"- 材料：{ga['label']}，{ga['src']}", f"- w＝{wg:.2f} kN/m", *_lines(sr["spans_mm"]), f"- 控制：{gov(sr['governs'])} → 支柱間距 {s3} mm", "",
               "## 6. 支柱", f"- 每支支柱載重＝{q:.2f}×{s2/1000:.3f}×{s3/1000:.3f}＝{P:.2f} kN"]
        sh2 = inp.get("shore", {})
        if sh2.get("kind") == "wood":
            a2 = allowable(sh2["species"], sh2["grade"], sh2["size"], CD=sh2.get("CD", 1.25), wet=sh2.get("wet", False)); sc = section(sh2["size"])
            cap = wood_shore(a2["Fc_star"], a2["Emin"], min(sc["b"], sc["d"]), sh2["le_m"] * 1000, sc["A"]); R["shore"] = cap
            md += [f"- 木支柱（原書美國材料參考）le＝{sh2['le_m']} m：le/d＝{cap['le_d']}、容許 {cap.get('Pc_kN')} kN → {'OK' if cap.get('Pc_kN', 0) >= P else 'NG'}"]
        else:
            cap = sh2.get("safe_load_kN"); R["shore"] = {"safe_load_kN": cap, "type": sh2.get("type", "可調鋼管支柱（CNS 5644）")}
            md += [f"- {sh2.get('type', '可調鋼管支柱（CNS 5644）')} 容許載重：{cap if cap else '〔待提供：CNS 5644／5645 試驗或製造商型錄，依高度與水平繫條配置〕'} kN" + (f" → {'OK' if cap >= P else 'NG'}" if cap else ""),
                   "- 法規：可調鋼管支柱不得連接使用；高度超過 3.5 m 者每隔 2 m 內設縱橫向水平繫條（營造安全衛生設施標準第 135 條）；支柱基礎依第 132 條處理。"]
        md += [""]
        if inp.get("bracing"):
            b = inp["bracing"]; dl = b.get("dl_kPa", L["concrete_kPa"] + 15 * PSF); H = slab_bracing_min(dl, b["width_m"])
            R["bracing"] = {"Hmin_kNm": H}
            md += ["## 7. 側向支撐", f"- 最小側向力＝max(1.46, 2%×{dl:.2f}×{b['width_m']})＝{H:.2f} kN/m，沿板緣任一方向作用（原書 Table 5-8 SI 等式）", ""]
    md += ["## 結論與聲明", "- 數值由 formwork_calc.py 計算；各材料容許值來源已逐項標示，標示【未註明來源】者須補件。",
           "- 原書美國材料參考值僅供比較；台灣案件應以 CNS 試驗報告、製造商資料或契約值為準。",
           "- 本計算書須經專任工程人員或執業技師複核簽章後方可據以施工。"]
    return R, "\n".join(md)

# ---------- 原書例題回歸驗證（以 SI 計算，換回原書單位比對） ----------
def verify():
    rows = []
    def chk(name, got, exp, tol=0.01):
        ok = abs(got - exp) <= max(tol * abs(exp), 0.051 if abs(exp) < 50 else 0.5)
        rows.append((name, got, exp, ok)); return ok
    kPa2psf = lambda p: p / PSF
    L = lambda m, h, R, T, Cc=1.0, **k: kPa2psf(lateral_pressure(m, h * FT, R * FT, f2c(T), 150 * PCF, Cc, **k)["Pm"])
    Lc = lambda m, h, R, T, Cc=1.0: kPa2psf(lateral_pressure(m, h * FT, R * FT, f2c(T), 150 * PCF, Cc)["Pm_calc"])
    chk("Ex3-1 牆 Pm psf", L("wall", 12, 5, 70), 793)
    chk("Ex3-2 牆 Pm（γh 上限）", L("wall", 8, 10, 60, 1.2), 1200)
    chk("Ex3-2 公式值", Lc("wall", 8, 10, 60, 1.2), 1608)
    chk("Ex3-3 R ft/hr", rate_from_pump(18 * 0.764555, 60 * FT, 15 * IN / 1000) / FT, 6.5)
    chk("Ex3-3 Pm（R=6.5）", L("wall", 9, 6.5, 80), 882)
    chk("Ex3-4 柱 Pm", L("column", 14, 7, 50), 1410)
    chk("Ex3-5 柱 Pm（γh 上限）", L("column", 12, 12, 60, 1.2), 1800)
    chk("Ex3-6 泵送 1.25γh", L("column", 10, 0, 70, pump_from_base=True), 1875)
    chk("Ex3-9 板 DL+LL psf", slab_load(6 * IN, 150 * PCF)["total_kPa"] / PSF, 135)
    chk("Ex3-7 集中載重 lb", (150 * PCF * (20 * FT) ** 2 * 8 * IN / 1000 + FORM_DL * (20 * FT) ** 2 + LL_MOT * (20 * FT) ** 2) * 1000 / LBF, 74000)
    chk("Ex3-8 梁底線載重 plf", (150 * PCF * 16 * IN / 1000 * 24 * IN / 1000 + 5 * PSF * 16 * IN / 1000 + LL * 16 * IN / 1000) / PLF, 470)
    chk("Table3-6 8 in. 機動 psf", (slab_load(8 * IN, 150 * PCF, 0, True)["total_calc_kPa"]) / PSF, 175)
    a = allowable("HF", "No.2", "3x8"); chk("Ex4-1 F'b psi", a["Fb"] / PSI, 1275); chk("Ex4-1 F'v psi", a["Fv"] / PSI, 187.5)
    a = allowable("SP", "No.1", "2x8", wet=True, flat=True); chk("Ex4-2 F'b psi", a["Fb"] / PSI, 1832, 0.005)
    # 合板單位換算：in.⁴/ft→mm⁴/m 等
    pm = 1000 / 304.8; I4 = lambda x: x * IN ** 4 * pm; S3 = lambda x: x * IN ** 3 * pm; Q2 = lambda x: x * IN ** 2 * pm
    p = ply_pressure(16 * IN, 1400 * PSI, 53 * PSI, 1.5e6 * PSI, S3(0.412), I4(0.197), Q2(6.762))
    chk("Ex5-13 彎曲容許壓力 psf", p["pressure_kPa"]["bending"] / PSF, 270); chk("Ex5-15 滾動剪力 psf", p["pressure_kPa"]["rolling_shear"] / PSF, 494)
    chk("Ex5-12 彎曲跨距 in.", math.sqrt(10 * 1930 * PSI * S3(0.737) / (900 * PSF)) / IN, 13.8, 0.01)
    chk("Ex5-14 彎曲容許壓力 psf", ply_pressure(24 * IN, 1930 * PSI, 72 * PSI, 1.65e6 * PSI, S3(0.455), I4(0.199), Q2(7.187))["pressure_kPa"]["bending"] / PSF, 183)
    dd = plywood_deflection(250 * PSF, 16.5 * IN, 1.65e6 * PSI, I4(0.199), Ee=1.5e6 * PSI, t=0.75 * IN)
    chk("Ex5-16 彎曲撓度 in.", dd["bending_defl_mm"] / IN, 0.035, 0.03); chk("Ex5-17 剪力撓度 in.", dd["shear_defl_mm"] / IN, 0.012, 0.05)
    s = wood_shore(1600 * PSI, 580000 * PSI, 3.5 * IN, 72 * IN, 19.25 * IN ** 2)
    chk("Ex5-18 Fc psi", s["Fc_MPa"] / PSI, 897.6, 0.005); chk("Ex5-18 Pc lb", s["Pc_kN"] * 1000 / LBF, 17279, 0.005)
    wl = lambda plf: plf * PLF
    sp = ply_spans(825 * PSF, 2062 * PSI, 66 * PSI, 1.8e6 * PSI, S3(0.515), I4(0.278), Q2(8.050), defl=("l/360", "1/16in"))
    for k, e in (("bending", 12.4), ("rolling_shear", 12.8), ("defl_l/360", 14.3), ("defl_1/16in", 16.0)): chk(f"Ch5 牆面板 {k} in.", sp["spans_mm"][k] / IN, e, 0.02)
    D = ("l/360", "1/16in")
    def bs(w, Fb, Fv, E, b, d, S, I, cond="multi"):
        r = beam_spans(wl(w), Fb * PSI, Fv * PSI, E * PSI, b * IN, d * IN, S * IN ** 3, I * IN ** 4, cond, D)
        return {k: v / IN for k, v in r["spans_mm"].items()}
    st = bs(825, 1875, 218, 1.6e6, 1.5, 3.5, 3.06, 5.36)
    for k, e in (("bending", 28.9), ("shear", 24.8), ("defl_l/360", 36.9), ("defl_1/16in", 32.6)): chk(f"Ch5 牆小肋 {k}", st[k], e, 0.02)
    wv = bs(1650, 1875, 218, 1.6e6, 3.0, 3.5, 6.12, 10.72)
    for k, e in (("bending", 28.8), ("shear", 24.7), ("defl_l/360", 36.9), ("defl_1/16in", 32.9)): chk(f"Ch5 牆大肋 {k}", wv[k], e, 0.02)
    chk("Ch5 繫結器拉力 lb", 825 * PSF * (2 * FT) * (2 * FT) * 1000 / LBF, 3300)
    chk("Ch5 13.3 kN（3,000 lb）繫結器最大間距 in.", (3000 * LBF / 1000) / (1650 * PLF) / FT * 12, 21.8, 0.01)
    bf = brace_force(125 * PLF, 9 * FT, 10 * FT, 6 * FT, 10 * FT); chk("Ex5-19 斜撐軸力 lb", bf["axial_kN"] * 1000 / LBF, 2188); chk("Ex5-19 垂直反力 lb", bf["V_kN"] * 1000 / LBF, 1875)
    bf = brace_force(125 * PLF, 9 * FT, 10 * FT, 6 * FT, 8 * FT); chk("Ex5-20 H lb", bf["H_kN"] * 1000 / LBF, 1406); chk("Ex5-20 軸力 lb", bf["axial_kN"] * 1000 / LBF, 2343)
    chk("Ch5 板載重 psf", slab_load(7 * IN, 150 * PCF, 5.5 * PSF)["total_kPa"] / PSF, 143)
    sp = ply_spans(143 * PSF, 1025 * PSI, 55 * PSI, 1.3e6 * PSI, S3(0.515), I4(0.278), Q2(8.05), defl=D)
    for k, e in (("rolling_shear", 61.9), ("defl_l/360", 23.0), ("defl_1/16in", 22.9)): chk(f"Ch5 板面板 {k}", sp["spans_mm"][k] / IN, e, 0.02)
    chk("Ch5 板面板 bending（原書印 20.0，正確 21.0）", sp["spans_mm"]["bending"] / IN, 21.0, 0.02)
    a = allowable("DFL", "No.2", "4x4", wet=True); chk("Ch5 小梁 F'b psi", a["Fb"] / PSI, 1434, 0.005); chk("Ch5 小梁 F'v psi", a["Fv"] / PSI, 218, 0.005)
    jr = bs(238, 1434, 218, 1.44e6, 3.5, 3.5, 7.15, 12.51)
    for k, e in (("bending", 71.9), ("shear", 150.6), ("defl_l/360", 71.6), ("defl_1/16in", 53.6)): chk(f"Ch5 小梁 {k}", jr[k], e, 0.02)
    sr = bs(572, 1243, 218, 1.44e6, 3.5, 5.5, 17.65, 48.53)
    for k, e in (("bending", 67.8), ("shear", 104.9), ("defl_l/360", 83.9), ("defl_1/16in", 60.4)): chk(f"Ch5 大梁 {k}", sr[k], e, 0.02)
    a = allowable("DFL", "No.2", "4x6", wet=True); chk("Ch5 大梁 F'b psi", a["Fb"] / PSI, 1243, 0.005)
    chk("Ch5 承壓 小梁－大梁 psi", bearing(953 * LBF / 1000, 12.25 * IN ** 2, 418.75 * PSI)["fc_perp_MPa"] / PSI, 77.8)
    chk("Ch6 梁支柱線載重 plf", ((23 * 15 + 5 * 15) * IN ** 2 / 1e6 * 150 * PCF + 8 * PSF * 2.5 * FT + LL * 2.5 * FT) / PLF, 583, 0.01)
    sh = lambda Fc, E, le_ft: wood_shore(Fc * PSI, E * PSI, 3.5 * IN, le_ft * 12 * IN, 12.25 * IN ** 2)["Pc_kN"] * 1000 / LBF
    chk("Table5-5 4x4 10ft lb", sh(1552, 580000, 10), 4672, 0.005); chk("Ch6 4x4 6ft lb", sh(1650, 580000, 6), 11076, 0.005); chk("Ch6 4x4 12ft lb", sh(1650, 580000, 12), 3318, 0.005)
    bb = bs(583, 1170, 175, 1.6e6, 15, 1.5, 5.625, 4.218)
    for k, e in (("bending", 36.8), ("shear", 89.4), ("defl_l/360", 38.2)): chk(f"Ch6 梁底 {k}", bb[k], e, 0.02)
    chk("Ex7-1 衝擊力 lb", bucket_impact(3000 * 0.45359237, 4 * FT, 5) * 1000 / LBF, 300, 0.01)
    chk("Ch7 料車 5s lb", buggy_force(3000 * 0.45359237, 10 * 1.609344, 5) * 1000 / LBF, 274, 0.01)
    chk("Ch7 料車 3s lb", buggy_force(3000 * 0.45359237, 10 * 1.609344, 3) * 1000 / LBF, 457, 0.01)
    sp = ply_spans(600 * PSF, 1930 * PSI, 72 * PSI, 1.65e6 * PSI, S3(0.455), I4(0.199), Q2(7.187), defl=D)
    for k, e in (("bending", 13.2), ("rolling_shear", 17.2), ("defl_l/360", 13.8), ("defl_1/16in", 15.6)): chk(f"Ex8-1 面板 {k}", sp["spans_mm"][k] / IN, e, 0.02)
    pl = bs(600, 1687, 225, 1.6e6, 3.0, 3.5, 6.12, 10.72)
    for k, e in (("bending", 45.4), ("shear", 57.4), ("defl_l/360", 51.7), ("defl_1/16in", 42.0)): chk(f"Ex8-1 雙板 {k}", pl[k], e, 0.02)
    c1 = bs(900, 1125, 225, 1.6e6, 12, 1.5, 4.5, 3.375)
    for k, e in (("bending", 25.9), ("shear", 60.6), ("defl_l/360", 30.7), ("defl_1/16in", 28.4)): chk(f"Ex10-1 {k}", c1[k], e, 0.02)
    a = allowable("SP", "No.2", "2x4", flat=True); chk("Ex10-2 F'b psi", a["Fb"] / PSI, 2062.5, 0.005)
    c2 = bs(1172, 2062.5, 218.7, 1.6e6, 3.5, 1.5, 1.313, 0.984)
    for k, e in (("bending", 16.6), ("shear", 15.5), ("defl_l/360", 18.6), ("defl_1/16in", 19.6)): chk(f"Ex10-2 {k}", c2[k], e, 0.02)
    chk("Ex10-3 S in³", yoke_S(900 * PSF, 12 * IN, 16 * IN, 1093 * PSI) / IN ** 3, 2.19, 0.01)
    chk("Ex10-4 S in³", yoke_S(900 * PSF, 12 * IN, 16 * IN, 1093 * PSI, 28 * IN) / IN ** 3, 5.48, 0.01)
    sp = ply_spans(150 * PSF, 1930 * PSI, 72 * PSI, 1.65e6 * PSI, S3(0.455), I4(0.199), Q2(7.186), defl=D)
    for k, e in (("bending", 26.5), ("rolling_shear", 68.9), ("defl_l/360", 21.9), ("defl_1/16in", 22.1)): chk(f"Ex11-1 {k}", sp["spans_mm"][k] / IN, e, 0.02)
    j2 = bs(250, 1875, 225, 1.7e6, 3.5, 3.5, 7.15, 12.51, "single")
    for k, e in (("bending", 71.7), ("shear", 183.4), ("defl_l/360", 60.1), ("defl_1/16in", 47.0)): chk(f"Ex11-2 {k}", j2[k], e, 0.02)
    shl = shell(60 * FT, 10 * FT); chk("Ex13-1 R ft", shl["R_m"] / FT, 50); chk("Ex13-1 邊緣角度", shl["edge_slope_deg"], 36.87, 0.001)
    T57 = {4: (30, 20, 40, 50, 60), 6: (45, 30, 60, 75, 90), 8: (100, 100, 100, 100, 120), 10: (100, 100, 100, 125, 150), 12: (100, 100, 120, 150, 180),
           14: (105, 100, 140, 175, 210), 16: (120, 100, 160, 200, 240), 18: (135, 100, 180, 225, 270), 20: (150, 100, 200, 250, 300)}
    bad = sum(1 for h, vals in T57.items() for q, v in zip((None, 10, 20, 25, 30), vals)
              if abs(wall_bracing_min(h * FT, None if q is None else q * PSF) / PLF - v) > 0.6)
    chk("Table5-7 不符格數", bad, 0)
    T58 = {65: (100, 100, 100, 104, 130), 90: (100, 100, 108, 144, 180), 115: (100, 100, 138, 184, 230), 140: (100, 112, 168, 224, 280),
           165: (100, 132, 198, 264, 330), 190: (100, 152, 228, 304, 380), 215: (100, 172, 258, 344, 430), 265: (106, 212, 318, 424, 530)}
    bad = sum(1 for dl, vals in T58.items() for wd, v in zip((20, 40, 60, 80, 100), vals) if abs(slab_bracing_min(dl * PSF, wd * FT) / PLF - v) > 0.6)
    chk("Table5-8 不符格數", bad, 0)
    odd = []
    for Rr, vals in {22: (5100, 4110, 3450, 2979, 2730, 2350, 2130), 23: (5325, 4290, 3600, 3107, 3525, 2450, 2220)}.items():
        for T, v in zip((40, 50, 60, 70, 80, 90, 100), vals):
            c = 150 + 9000 * Rr / T
            if abs(c - v) > 1.5: odd.append(f"原書 Table 3-5 R={Rr*0.3048:.2f} m/h、T={(T-32)/1.8:.1f} °C：表值 {v*PSF:.1f} kPa，公式 {c*PSF:.1f} kPa（原書英制 {v}／{c:.0f} psf）")
    for T, v in zip((40, 50, 60, 70, 80, 90, 100), (2145, 1746, 1450, 1290, 1148, 1037, 948)):
        c = 150 + 43400 / T + 2800 * 13 / T
        if abs(c - v) > 1.5: odd.append(f"原書 Table 3-3／3-4 R=3.96 m/h、T={(T-32)/1.8:.1f} °C：表值 {v*PSF:.1f} kPa，公式 {c*PSF:.1f} kPa（原書英制 {v}／{c:.0f} psf）")
    # SI 常數與門檻（換算正確性）
    chk("SI 常數 K0 kPa", K0, 7.182, 0.001); chk("SI 常數 K1", K1, 785.4, 0.001); chk("SI 常數 K2", K2, 1154.4, 0.001); chk("SI 常數 K3", K3, 244.35, 0.001)
    return rows, odd, sum(1 for r in rows if r[3])

def main():
    ap = argparse.ArgumentParser(description="模板大師計算程式（公制）")
    sub = ap.add_subparsers(dest="cmd", required=True)
    p = sub.add_parser("pressure", help="側壓力 kPa"); p.add_argument("member", choices=["wall", "column"]); p.add_argument("--h", type=float, required=True, help="澆置高度 m")
    p.add_argument("--R", type=float, default=0, help="澆置速率 m/h"); p.add_argument("--T", type=float, default=20, help="混凝土溫度 °C"); p.add_argument("--g", type=float, default=23.56, help="單位重 kN/m³")
    p.add_argument("--Cc", type=float, default=1.0); p.add_argument("--pump-base", action="store_true"); p.add_argument("--full", action="store_true", help="自充填或強力振動：取 γh")
    p = sub.add_parser("rate", help="澆置速率"); p.add_argument("--Q", type=float, required=True, help="m³/h"); p.add_argument("--L", type=float, required=True, help="牆長 m"); p.add_argument("--t", type=float, required=True, help="牆厚 m")
    p = sub.add_parser("slabload", help="樓板垂直載重 kPa"); p.add_argument("--t", type=float, required=True, help="板厚 mm"); p.add_argument("--g", type=float, default=23.56)
    p.add_argument("--form-dl", type=float, help="模板自重 kPa（預設 0.48）"); p.add_argument("--motorized", action="store_true"); p.add_argument("--ll", type=float, help="施工活載重 kPa")
    p = sub.add_parser("stress", help="原書美國木材容許應力 MPa（比較用）"); p.add_argument("--species", required=True, choices=["SP", "DFL", "HF", "SPF"]); p.add_argument("--grade", default="No.2"); p.add_argument("--size", required=True)
    p.add_argument("--CD", type=float, default=1.25); p.add_argument("--wet", action="store_true"); p.add_argument("--flat", action="store_true")
    p = sub.add_parser("span", help="木梁容許跨距 mm"); p.add_argument("--w", type=float, required=True, help="kN/m"); p.add_argument("--Fb", type=float, required=True, help="MPa"); p.add_argument("--Fv", type=float, required=True, help="MPa")
    p.add_argument("--E", type=float, required=True, help="MPa"); p.add_argument("--b", type=float, required=True, help="mm"); p.add_argument("--d", type=float, required=True, help="mm"); p.add_argument("--n", type=int, default=1, help="並列支數")
    p.add_argument("--cond", choices=["single", "multi"], default="multi"); p.add_argument("--defl", default="l/360,1.6mm")
    p = sub.add_parser("ply", help="面板容許跨距 mm"); p.add_argument("--q", type=float, required=True, help="kPa"); p.add_argument("--Fb", type=float, required=True); p.add_argument("--Fs", type=float, required=True)
    p.add_argument("--E", type=float, required=True); p.add_argument("--Se", type=float, help="mm³/m"); p.add_argument("--I", type=float, help="mm⁴/m"); p.add_argument("--IbQ", type=float, help="mm²/m")
    p.add_argument("--t", type=float, help="面板厚 mm（未給 Se、I、IbQ 時以實心矩形近似，結果標示近似）")
    p.add_argument("--cond", choices=["single", "two", "multi"], default="multi"); p.add_argument("--defl", default="l/360,1.6mm")
    p = sub.add_parser("shore", help="木支柱容量 kN（原書 Eq.5-61）"); p.add_argument("--Fc", type=float, required=True, help="F*c MPa"); p.add_argument("--Emin", type=float, required=True, help="MPa")
    p.add_argument("--b", type=float, required=True, help="mm"); p.add_argument("--d", type=float, required=True, help="mm"); p.add_argument("--le", type=float, required=True, help="有效長度 m")
    p = sub.add_parser("brace", help="側向力與斜撐"); p.add_argument("kind", choices=["wall", "slab"]); p.add_argument("--h", type=float, help="模高 m"); p.add_argument("--wind", type=float, help="風壓 kPa")
    p.add_argument("--dl", type=float, help="靜載重 kPa"); p.add_argument("--width", type=float, help="板寬 m"); p.add_argument("--spacing", type=float, help="斜撐間距 m"); p.add_argument("--x", type=float, help="水平距 m"); p.add_argument("--y", type=float, help="斜撐上端高度 m")
    p = sub.add_parser("impact", help="落料衝擊、料車水平力 kN"); p.add_argument("--M", type=float, required=True, help="質量 kg"); p.add_argument("--h", type=float, help="落距 m"); p.add_argument("--T", type=float, help="卸料時間 s")
    p.add_argument("--v", type=float, help="車速 km/h"); p.add_argument("--t", type=float, help="停止時間 s")
    p = sub.add_parser("yoke", help="木柱箍需要斷面模數 mm³"); p.add_argument("--P", type=float, required=True, help="kPa"); p.add_argument("--l", type=float, required=True, help="柱箍間距 mm")
    p.add_argument("--x", type=float, required=True, help="楔間距 mm"); p.add_argument("--Fb", type=float, required=True, help="MPa"); p.add_argument("--y", type=float, help="螺栓間距 mm")
    p = sub.add_parser("shell", help="薄殼幾何 m"); p.add_argument("--L", type=float, required=True); p.add_argument("--H", type=float, required=True); p.add_argument("--n", type=int, default=10)
    p = sub.add_parser("strip", help="最少拆模時間（結構混凝土施工規範表 4.7.1）"); p.add_argument("item", choices=list(STRIP_TW)); p.add_argument("--ll-gt-dl", action="store_true")
    p = sub.add_parser("design", help="整體設計與計算書"); p.add_argument("json"); p.add_argument("--out", default="formwork_calc_report")
    sub.add_parser("verify", help="原書例題回歸驗證")
    a = ap.parse_args(); J = lambda o: print(json.dumps(o, ensure_ascii=False, indent=1))
    if a.cmd == "pressure": J(lateral_pressure(a.member, a.h, a.R, a.T, a.g, a.Cc, pump_from_base=a.pump_base, full=a.full))
    elif a.cmd == "rate": J({"R_mh": round(rate_from_pump(a.Q, a.L, a.t), 3)})
    elif a.cmd == "slabload": J(slab_load(a.t, a.g, a.form_dl, a.motorized, a.ll))
    elif a.cmd == "stress": J(allowable(a.species, a.grade, a.size, a.CD, a.wet, a.flat))
    elif a.cmd == "span":
        s = rect(a.b, a.d, a.n); J(beam_spans(a.w, a.Fb, a.Fv, a.E, s["b"], s["d"], s["S"], s["I"], a.cond, tuple(a.defl.split(","))))
    elif a.cmd == "ply":
        approx = False
        if a.Se is None or a.I is None or a.IbQ is None:
            if not a.t: sys.exit("須提供 Se、I、IbQ（每公尺寬），或以 --t 近似")
            Se, I, IbQ = 1000 * a.t ** 2 / 6, 1000 * a.t ** 3 / 12, 1000 * a.t * 2 / 3; approx = True
        else: Se, I, IbQ = a.Se, a.I, a.IbQ
        o = ply_spans(a.q, a.Fb, a.Fs, a.E, Se, I, IbQ, a.cond, tuple(a.defl.split(",")))
        if approx: o["warning"] = "以實心矩形近似合板斷面（未考慮單板層向），僅供初估，正式計算須用製造商或試驗之有效斷面性質"
        J(o)
    elif a.cmd == "shore": J(wood_shore(a.Fc, a.Emin, min(a.b, a.d), a.le * 1000, a.b * a.d))
    elif a.cmd == "brace":
        if a.kind == "wall":
            H = wall_bracing_min(a.h, a.wind); o = {"Hmin_kNm": H}
            if a.spacing and a.x and a.y: o.update(brace_force(H, a.spacing, a.h, a.x, a.y))
            J(o)
        else: J({"Hmin_kNm": slab_bracing_min(a.dl, a.width)})
    elif a.cmd == "impact":
        o = {}
        if a.h is not None and a.T: o["bucket_F_kN"] = bucket_impact(a.M, a.h, a.T)
        if a.v is not None and a.t: o["buggy_F_kN"] = buggy_force(a.M, a.v, a.t)
        J(o)
    elif a.cmd == "yoke": J({"S_req_mm3": yoke_S(a.P, a.l, a.x, a.Fb, a.y)})
    elif a.cmd == "shell": J(shell(a.L, a.H, a.n))
    elif a.cmd == "strip":
        v = STRIP_TW[a.item]; J({"item": a.item, "min_time": v[1] if a.ll_gt_dl else v[0],
                                "source": "結構混凝土施工規範表 4.7.1（第 I 型水泥、不摻卜作嵐材料）；契約 03110 拆模時間表另有規定者從其規定；版或梁拆除支撐時工地養護試體強度不得低於設計強度 70%（4.7.5）"})
    elif a.cmd == "design":
        inp = json.load(open(a.json, encoding="utf-8")); R, md = design(inp)
        json.dump(R, open(a.out + ".json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)
        open(a.out + ".md", "w", encoding="utf-8").write(md); print(md)
    elif a.cmd == "verify":
        rows, odd, npass = verify()
        for n, g, e, ok in rows: print(f"{'PASS' if ok else 'FAIL'}  {n}：程式 {g:.4g}／原書 {e:.4g}")
        print(f"\n合計 {npass}/{len(rows)} 通過（程式以 SI 計算，結果換回原書美制單位與原書印刷值比對）")
        if odd:
            print("\n原書表值與公式不一致（以公式為準）："); [print("  - " + o) for o in odd]
        sys.exit(0 if npass == len(rows) else 1)

if __name__ == "__main__":
    main()

```

## formwork_tables.json

```json
{
 "_source": "Peurifoy & Oberlender, Formwork for Concrete Structures, 4th ed., McGraw-Hill, 2011（下稱原書）",
 "_units": "SI：尺寸 mm、斷面性質 mm²／mm³／mm⁴、應力與彈性模數 MPa、合板性質為每公尺寬；由原書美制轉錄值精確換算",
 "_note": "本檔僅收錄原書（美國）材料之參考值，供例題驗證與比較。台灣案件之 CNS 8057 合板、角材、可調鋼管支柱等容許值，須由試驗報告、製造商或契約提供，以 kind=user 輸入。",
 "lumber_S4S_dry": {
  "_table": "原書 Table 4-1（美制標稱尺寸，實際尺寸換算 mm）",
  "data": {
   "1x4": {
    "nominal_in": "1x4",
    "b": 19.0,
    "d": 88.9,
    "A": 1694.0,
    "Ix": 1115370.0,
    "Sx": 25093.0,
    "Iy": 51216.0,
    "Sy": 5377.0
   },
   "1x6": {
    "nominal_in": "1x6",
    "b": 19.0,
    "d": 139.7,
    "A": 2661.0,
    "Ix": 4328156.0,
    "Sx": 61964.0,
    "Iy": 80482.0,
    "Sy": 8450.0
   },
   "1x8": {
    "nominal_in": "1x8",
    "b": 19.0,
    "d": 184.1,
    "A": 3508.0,
    "Ix": 9913543.0,
    "Sx": 107668.0,
    "Iy": 106090.0,
    "Sy": 11138.0
   },
   "1x10": {
    "nominal_in": "1x10",
    "b": 19.0,
    "d": 234.9,
    "A": 4476.0,
    "Ix": 20589229.0,
    "Sx": 175265.0,
    "Iy": 135357.0,
    "Sy": 14211.0
   },
   "1x12": {
    "nominal_in": "1x12",
    "b": 19.0,
    "d": 285.8,
    "A": 5444.0,
    "Ix": 37040126.0,
    "Sx": 259248.0,
    "Iy": 164623.0,
    "Sy": 17283.0
   },
   "2x4": {
    "nominal_in": "2x4",
    "b": 38.1,
    "d": 88.9,
    "A": 3387.0,
    "Ix": 2230740.0,
    "Sx": 50185.0,
    "Iy": 409728.0,
    "Sy": 21508.0
   },
   "2x6": {
    "nominal_in": "2x6",
    "b": 38.1,
    "d": 139.7,
    "A": 5323.0,
    "Ix": 8656313.0,
    "Sx": 123927.0,
    "Iy": 643858.0,
    "Sy": 33798.0
   },
   "2x8": {
    "nominal_in": "2x8",
    "b": 38.1,
    "d": 184.1,
    "A": 7016.0,
    "Ix": 19827086.0,
    "Sx": 215336.0,
    "Iy": 848722.0,
    "Sy": 44552.0
   },
   "2x10": {
    "nominal_in": "2x10",
    "b": 38.1,
    "d": 234.9,
    "A": 8952.0,
    "Ix": 41178458.0,
    "Sx": 350530.0,
    "Iy": 1082852.0,
    "Sy": 56843.0
   },
   "2x12": {
    "nominal_in": "2x12",
    "b": 38.1,
    "d": 285.8,
    "A": 10887.0,
    "Ix": 74080251.0,
    "Sx": 518497.0,
    "Iy": 1316982.0,
    "Sy": 69133.0
   },
   "3x4": {
    "nominal_in": "3x4",
    "b": 63.5,
    "d": 88.9,
    "A": 5645.0,
    "Ix": 3717900.0,
    "Sx": 83642.0,
    "Iy": 1896888.0,
    "Sy": 59745.0
   },
   "3x6": {
    "nominal_in": "3x6",
    "b": 63.5,
    "d": 139.7,
    "A": 8871.0,
    "Ix": 14427188.0,
    "Sx": 206545.0,
    "Iy": 2980824.0,
    "Sy": 93884.0
   },
   "3x8": {
    "nominal_in": "3x8",
    "b": 63.5,
    "d": 184.1,
    "A": 11694.0,
    "Ix": 33045144.0,
    "Sx": 358894.0,
    "Iy": 3929268.0,
    "Sy": 123756.0
   },
   "3x10": {
    "nominal_in": "3x10",
    "b": 63.5,
    "d": 234.9,
    "A": 14919.0,
    "Ix": 68630763.0,
    "Sx": 584216.0,
    "Iy": 5013204.0,
    "Sy": 157896.0
   },
   "3x12": {
    "nominal_in": "3x12",
    "b": 63.5,
    "d": 285.8,
    "A": 18145.0,
    "Ix": 123467085.0,
    "Sx": 864162.0,
    "Iy": 6097140.0,
    "Sy": 192036.0
   },
   "4x4": {
    "nominal_in": "4x4",
    "b": 88.9,
    "d": 88.9,
    "A": 7903.0,
    "Ix": 5205061.0,
    "Sx": 117099.0,
    "Iy": 5205061.0,
    "Sy": 117099.0
   },
   "4x6": {
    "nominal_in": "4x6",
    "b": 88.9,
    "d": 139.7,
    "A": 12419.0,
    "Ix": 20198064.0,
    "Sx": 289163.0,
    "Iy": 8179381.0,
    "Sy": 184013.0
   },
   "4x8": {
    "nominal_in": "4x8",
    "b": 88.9,
    "d": 184.1,
    "A": 16371.0,
    "Ix": 46263202.0,
    "Sx": 502451.0,
    "Iy": 10781911.0,
    "Sy": 242563.0
   },
   "4x10": {
    "nominal_in": "4x10",
    "b": 88.9,
    "d": 234.9,
    "A": 20887.0,
    "Ix": 96083068.0,
    "Sx": 817902.0,
    "Iy": 13756232.0,
    "Sy": 309477.0
   },
   "4x12": {
    "nominal_in": "4x12",
    "b": 88.9,
    "d": 285.8,
    "A": 25403.0,
    "Ix": 172853920.0,
    "Sx": 1209826.0,
    "Iy": 16730552.0,
    "Sy": 376390.0
   },
   "2x2": {
    "nominal_in": "2x2",
    "b": 38.1,
    "d": 38.1,
    "A": 1452.0,
    "Ix": 175598.0,
    "Sx": 9218.0,
    "Iy": 175598.0,
    "Sy": 9218.0
   },
   "3x3": {
    "nominal_in": "3x3",
    "b": 63.5,
    "d": 63.5,
    "A": 4032.0,
    "Ix": 1354920.0,
    "Sx": 42675.0,
    "Iy": 1354920.0,
    "Sy": 42675.0
   },
   "5x5": {
    "nominal_in": "5x5",
    "b": 114.3,
    "d": 114.3,
    "A": 13064.0,
    "Ix": 14223408.0,
    "Sx": 248879.0,
    "Iy": 14223408.0,
    "Sy": 248879.0
   },
   "6x6": {
    "nominal_in": "6x6",
    "b": 139.7,
    "d": 139.7,
    "A": 19516.0,
    "Ix": 31739814.0,
    "Sx": 454400.0,
    "Iy": 31739814.0,
    "Sy": 454400.0
   },
   "6x8": {
    "nominal_in": "6x8",
    "b": 139.7,
    "d": 190.5,
    "A": 26613.0,
    "Ix": 80482248.0,
    "Sx": 844958.0,
    "Iy": 43281565.0,
    "Sy": 619636.0
   },
   "6x10": {
    "nominal_in": "6x10",
    "b": 139.7,
    "d": 241.3,
    "A": 33710.0,
    "Ix": 163563775.0,
    "Sx": 1355688.0,
    "Iy": 54823315.0,
    "Sy": 784872.0
   },
   "6x12": {
    "nominal_in": "6x12",
    "b": 139.7,
    "d": 292.1,
    "A": 40806.0,
    "Ix": 290141486.0,
    "Sx": 1986590.0,
    "Iy": 66365066.0,
    "Sy": 950108.0
   },
   "8x8": {
    "nominal_in": "8x8",
    "b": 190.5,
    "d": 190.5,
    "A": 36290.0,
    "Ix": 109748520.0,
    "Sx": 1152215.0,
    "Iy": 109748520.0,
    "Sy": 1152215.0
   },
   "8x10": {
    "nominal_in": "8x10",
    "b": 190.5,
    "d": 241.3,
    "A": 45968.0,
    "Ix": 223041512.0,
    "Sx": 1848666.0,
    "Iy": 139014793.0,
    "Sy": 1459473.0
   },
   "8x12": {
    "nominal_in": "8x12",
    "b": 190.5,
    "d": 292.1,
    "A": 55645.0,
    "Ix": 395647481.0,
    "Sx": 2708987.0,
    "Iy": 168281065.0,
    "Sy": 1766730.0
   },
   "10x10": {
    "nominal_in": "10x10",
    "b": 241.3,
    "d": 241.3,
    "A": 58226.0,
    "Ix": 282519248.0,
    "Sx": 2341643.0,
    "Iy": 282519248.0,
    "Sy": 2341643.0
   },
   "10x12": {
    "nominal_in": "10x12",
    "b": 241.3,
    "d": 292.1,
    "A": 70484.0,
    "Ix": 501153476.0,
    "Sx": 3431383.0,
    "Iy": 341996984.0,
    "Sy": 2834621.0
   },
   "12x12": {
    "nominal_in": "12x12",
    "b": 292.1,
    "d": 292.1,
    "A": 85322.0,
    "Ix": 606659471.0,
    "Sx": 4153779.0,
    "Iy": 606659471.0,
    "Sy": 4153779.0
   }
  }
 },
 "ref_design_values": {
  "_table": "原書 Table 4-2、4-3（MPa）",
  "_order": [
   "Fb",
   "Fv",
   "Fc_perp",
   "Fc_par",
   "E",
   "Emin"
  ],
  "SP": {
   "No.1": {
    "2-4": [
     12.7553,
     1.2066,
     3.8955,
     12.7553,
     11721.092,
     4274.7512
    ],
    "6": [
     11.3764,
     1.2066,
     3.8955,
     12.0658,
     11721.092,
     4274.7512
    ],
    "8": [
     10.3421,
     1.2066,
     3.8955,
     11.3764,
     11721.092,
     4274.7512
    ],
    "10": [
     8.9632,
     1.2066,
     3.8955,
     11.0316,
     11721.092,
     4274.7512
    ],
    "12": [
     8.6184,
     1.2066,
     3.8955,
     11.0316,
     11721.092,
     4274.7512
    ]
   },
   "No.2": {
    "2-4": [
     10.3421,
     1.2066,
     3.8955,
     11.3764,
     11031.616,
     3998.9608
    ],
    "6": [
     8.6184,
     1.2066,
     3.8955,
     11.0316,
     11031.616,
     3998.9608
    ],
    "8": [
     8.2737,
     1.2066,
     3.8955,
     10.6869,
     11031.616,
     3998.9608
    ],
    "10": [
     7.2395,
     1.2066,
     3.8955,
     10.3421,
     11031.616,
     3998.9608
    ],
    "12": [
     6.7224,
     1.2066,
     3.8955,
     9.9974,
     11031.616,
     3998.9608
    ]
   },
   "size_adjusted": true
  },
  "DFL": {
   "No.1": [
    6.8948,
    1.2411,
    4.3092,
    10.3421,
    11721.092,
    4274.7512
   ],
   "No.2": [
    6.2053,
    1.2411,
    4.3092,
    9.3079,
    11031.616,
    3998.9608
   ],
   "size_adjusted": false
  },
  "HF": {
   "No.1": [
    6.7224,
    1.0342,
    2.7924,
    9.3079,
    10342.14,
    3792.118
   ],
   "No.2": [
    5.8605,
    1.0342,
    2.7924,
    8.9632,
    8963.188,
    3240.5372
   ],
   "size_adjusted": false
  },
  "SPF": {
   "No.1": [
    6.0329,
    0.9308,
    2.9303,
    7.929,
    9652.664,
    3516.3276
   ],
   "No.2": [
    6.0329,
    0.9308,
    2.9303,
    7.929,
    9652.664,
    3516.3276
   ],
   "size_adjusted": false
  }
 },
 "CF_table_4_3a": {
  "_cols": [
   "Fb 2&3-in thick",
   "Fb 4-in thick",
   "Fc_par"
  ],
  "2": [
   1.5,
   1.5,
   1.15
  ],
  "3": [
   1.5,
   1.5,
   1.15
  ],
  "4": [
   1.5,
   1.5,
   1.15
  ],
  "5": [
   1.4,
   1.4,
   1.1
  ],
  "6": [
   1.3,
   1.3,
   1.1
  ],
  "8": [
   1.2,
   1.3,
   1.05
  ],
  "10": [
   1.1,
   1.2,
   1.0
  ],
  "12": [
   1.0,
   1.1,
   1.0
  ],
  "14+": [
   0.9,
   1.0,
   0.9
  ]
 },
 "CD_table_4_4": {
  "permanent": 0.9,
  "10yr": 1.0,
  "2mo": 1.15,
  "7day": 1.25,
  "10min": 1.6,
  "impact": 2.0,
  "_note": "E、Fc⊥ 不作載重時間調整"
 },
 "CM_table_4_5": {
  "Fb": 0.85,
  "Fv": 0.97,
  "Fc_perp": 0.67,
  "Fc_par": 0.8,
  "E": 0.9,
  "_note": "(Fb)(CF)<7.93 MPa（1,150 psi）時 Fb 之 CM=1.0；(Fc//)(CF)<5.17 MPa（750 psi）時 Fc// 之 CM=1.0"
 },
 "Cfu_table_4_7": {
  "_cols": [
   "2&3-in thick",
   "4-in thick"
  ],
  "2": [
   1.0,
   null
  ],
  "3": [
   1.0,
   null
  ],
  "4": [
   1.1,
   1.0
  ],
  "5": [
   1.1,
   1.05
  ],
  "6": [
   1.15,
   1.05
  ],
  "8": [
   1.15,
   1.05
  ],
  "10+": [
   1.2,
   1.1
  ]
 },
 "Cb_formula": "Cb=(lb+9.5)/lb，lb<150 mm 且距端≥75 mm（原書 Table 4-8：(lb+⅜ in.)/lb）",
 "plyform_table_4_11": {
  "_cols": [
   "wt_kPa",
   "I_par",
   "Se_par",
   "IbQ_par",
   "I_perp",
   "Se_perp",
   "IbQ_perp"
  ],
  "_note": "每公尺寬；par＝面紋垂直支承（across）",
  "_missing": "StructI 19/32 列於 PDF 文字層缺損，未轉錄",
  "ClassI": {
   "15/32": [
    0.067,
    90129.0,
    13118.0,
    10039.0,
    24581.0,
    5753.0,
    5120.0
   ],
   "1/2": [
    0.072,
    105150.0,
    14409.0,
    10907.0,
    32774.0,
    6989.0,
    5798.0
   ],
   "19/32": [
    0.081,
    157043.0,
    18011.0,
    11510.0,
    39602.0,
    7849.0,
    5999.0
   ],
   "5/8": [
    0.086,
    177527.0,
    19247.0,
    12101.0,
    51892.0,
    9409.0,
    6549.0
   ],
   "23/32": [
    0.101,
    245806.0,
    23118.0,
    14836.0,
    98322.0,
    13280.0,
    8039.0
   ],
   "3/4": [
    0.105,
    271752.0,
    24462.0,
    15212.0,
    125634.0,
    16452.0,
    8600.0
   ],
   "7/8": [
    0.124,
    404214.0,
    31398.0,
    18108.0,
    206204.0,
    22688.0,
    12759.0
   ],
   "1-1/8": [
    0.158,
    756536.0,
    45645.0,
    22077.0,
    543504.0,
    42957.0,
    17820.0
   ]
  },
  "ClassII": {
   "15/32": [
    0.067,
    86032.0,
    13064.0,
    9523.0,
    20484.0,
    7419.0,
    5152.0
   ],
   "1/2": [
    0.072,
    102419.0,
    14355.0,
    10353.0,
    27312.0,
    8978.0,
    5772.0
   ],
   "19/32": [
    0.081,
    157043.0,
    17957.0,
    11273.0,
    34140.0,
    10108.0,
    5952.0
   ],
   "5/8": [
    0.086,
    177527.0,
    19194.0,
    11839.0,
    43699.0,
    12097.0,
    6507.0
   ],
   "23/32": [
    0.101,
    245806.0,
    23118.0,
    13767.0,
    81935.0,
    17043.0,
    8003.0
   ],
   "3/4": [
    0.105,
    270387.0,
    24409.0,
    14036.0,
    102419.0,
    21075.0,
    8570.0
   ],
   "7/8": [
    0.124,
    409677.0,
    31774.0,
    16912.0,
    167967.0,
    29140.0,
    12694.0
   ],
   "1-1/8": [
    0.158,
    772923.0,
    46720.0,
    20259.0,
    441085.0,
    55000.0,
    17755.0
   ]
  },
  "StructI": {
   "15/32": [
    0.067,
    91494.0,
    13226.0,
    9531.0,
    28677.0,
    7903.0,
    5091.0
   ],
   "1/2": [
    0.072,
    106516.0,
    14570.0,
    10389.0,
    39602.0,
    9570.0,
    5768.0
   ],
   "5/8": [
    0.086,
    178892.0,
    19409.0,
    11129.0,
    61451.0,
    12796.0,
    6505.0
   ],
   "23/32": [
    0.101,
    249903.0,
    23602.0,
    12931.0,
    116075.0,
    18172.0,
    8001.0
   ],
   "3/4": [
    0.105,
    275849.0,
    24946.0,
    13100.0,
    147484.0,
    22473.0,
    8566.0
   ],
   "7/8": [
    0.124,
    432892.0,
    33656.0,
    15958.0,
    244440.0,
    31129.0,
    12681.0
   ],
   "1-1/8": [
    0.158,
    850762.0,
    51344.0,
    18713.0,
    647289.0,
    59032.0,
    17731.0
   ]
  }
 },
 "plyform_table_4_12": {
  "ClassI": {
   "Fb": 13.3069,
   "Fs": 0.4964,
   "E": 11376.354,
   "Ee": 10342.14
  },
  "ClassII": {
   "Fb": 9.17,
   "Fs": 0.4964,
   "E": 9859.5068,
   "Ee": 8963.188
  },
  "StructI": {
   "Fb": 13.3069,
   "Fs": 0.7033,
   "E": 11376.354,
   "Ee": 10342.14
  },
  "_note": "APA 已調整值（MPa）"
 },
 "plywood_table_4_9": {
  "_cols": [
   "wt_kPa",
   "t_shear",
   "A_par",
   "I_par",
   "Se_par",
   "IbQ_par",
   "A_perp",
   "I_perp",
   "Se_perp",
   "IbQ_perp"
  ],
  "DiffSpecies": {
   "1/4": [
    0.038,
    6.78,
    2108.0,
    10925.0,
    3172.0,
    4254.0,
    737.0,
    1366.0,
    484.0,
    4274.0
   ],
   "3/8": [
    0.053,
    7.32,
    2766.0,
    36871.0,
    6720.0,
    6536.0,
    1325.0,
    2731.0,
    1237.0,
    7430.0
   ],
   "1/2": [
    0.072,
    10.79,
    4121.0,
    105150.0,
    12688.0,
    9453.0,
    2625.0,
    12290.0,
    4677.0,
    5825.0
   ],
   "5/8": [
    0.086,
    13.97,
    5239.0,
    176161.0,
    18226.0,
    12327.0,
    3234.0,
    36871.0,
    8817.0,
    6602.0
   ],
   "3/4": [
    0.105,
    14.43,
    6104.0,
    269021.0,
    22150.0,
    14313.0,
    4405.0,
    86032.0,
    15323.0,
    8634.0
   ],
   "7/8": [
    0.124,
    14.88,
    6227.0,
    379634.0,
    27688.0,
    17039.0,
    5611.0,
    142021.0,
    21183.0,
    10748.0
   ],
   "1": [
    0.144,
    20.75,
    7876.0,
    577644.0,
    35699.0,
    18800.0,
    6695.0,
    252634.0,
    31774.0,
    14882.0
   ],
   "1-1/8": [
    0.158,
    21.23,
    8158.0,
    748343.0,
    44086.0,
    20919.0,
    6731.0,
    370075.0,
    40000.0,
    17839.0
   ]
  },
  "StructI_Marine": {
   "1/4": [
    0.038,
    8.69,
    2709.0,
    16387.0,
    4462.0,
    4252.0,
    1325.0,
    1366.0,
    699.0,
    5764.0
   ],
   "3/8": [
    0.053,
    9.47,
    3556.0,
    51892.0,
    9516.0,
    6532.0,
    2383.0,
    2731.0,
    1774.0,
    10429.0
   ],
   "1/2": [
    0.072,
    13.84,
    4121.0,
    106516.0,
    14570.0,
    9434.0,
    4724.0,
    19118.0,
    6613.0,
    5768.0
   ],
   "5/8": [
    0.086,
    18.21,
    6587.0,
    178892.0,
    19409.0,
    12560.0,
    5823.0,
    61451.0,
    12796.0,
    6505.0
   ],
   "3/4": [
    0.105,
    19.0,
    8145.0,
    275849.0,
    24946.0,
    13100.0,
    7927.0,
    147484.0,
    22473.0,
    8566.0
   ],
   "7/8": [
    0.124,
    19.76,
    8365.0,
    393290.0,
    30591.0,
    15958.0,
    10101.0,
    244440.0,
    31129.0,
    10681.0
   ],
   "1": [
    0.144,
    27.71,
    11038.0,
    654117.0,
    44462.0,
    16887.0,
    12050.0,
    438354.0,
    46774.0,
    14776.0
   ],
   "1-1/8": [
    0.158,
    28.47,
    11839.0,
    850762.0,
    51344.0,
    18713.0,
    12116.0,
    647289.0,
    59032.0,
    17731.0
   ]
  }
 },
 "plywood_table_4_10": {
  "_note": "MPa，正常載重時間；短期 Fb、Fs ×1.25，E 不調整",
  "_cols": [
   "S1_wet",
   "S1_dry",
   "S2_wet",
   "S2_dry",
   "S3_dry"
  ],
  "Fb": {
   "1": [
    9.8595,
    13.7895,
    8.2048,
    11.3764,
    11.3764
   ],
   "2-3": [
    6.7569,
    9.6527,
    5.6537,
    8.2737,
    8.2737
   ],
   "4": [
    6.4811,
    9.17,
    5.3779,
    7.6532,
    7.6532
   ]
  },
  "Fv": {
   "1": [
    1.0687,
    1.31,
    1.0687,
    1.31,
    1.1032
   ],
   "2-3": [
    0.8274,
    0.9653,
    0.8274,
    0.9653,
    0.8274
   ],
   "4": [
    0.7584,
    0.8963,
    0.7584,
    0.8963,
    0.7929
   ]
  },
  "Fs": {
   "StructI_Marine": [
    0.4344,
    0.5171,
    0.4344,
    0.5171,
    null
   ],
   "Others": [
    0.3034,
    0.3654,
    0.3034,
    0.3654,
    0.3309
   ]
  },
  "E": {
   "1": [
    10342.14,
    12410.568,
    10342.14,
    12410.568,
    12410.568
   ],
   "2": [
    8963.188,
    10342.14,
    8963.188,
    10342.14,
    10342.14
   ],
   "3": [
    7584.236,
    8273.712,
    7584.236,
    8273.712,
    8273.712
   ]
  },
  "Fc_perp": {
   "1": [
    1.4479,
    2.3442,
    1.4479,
    2.3442,
    2.3442
   ],
   "2-3": [
    0.9308,
    1.4479,
    0.9308,
    1.4479,
    1.4479
   ],
   "4": [
    0.7239,
    1.1032,
    0.7239,
    1.1032,
    1.1032
   ]
  }
 },
 "ties_accessories": {
  "snap_tie_typical_kN": 13.3,
  "heavy_tie_kN": 17.8,
  "SF_form_tie": 2.0,
  "SF_form_anchor": {
   "form_weight_and_pressure": 2.0,
   "with_live_load_and_impact": 3.0
  },
  "SF_form_hanger": 2.0,
  "SF_insert_precast_as_form": 2.0,
  "_table": "原書 Table 5-10；以極限強度為準"
 },
 "shoring_SF_SSFI": {
  "tubular_frame": 2.5,
  "tube_coupler": 2.5,
  "system": 2.5,
  "single_post_fabricated": 3.0,
  "rolling_shore_bracket": 2.5,
  "_source": "Appendix B（SSFI）Sec.3–8"
 }
}
```
